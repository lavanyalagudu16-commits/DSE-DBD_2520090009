import React, { useState } from 'react';
import { SignDialect, SignEntry } from './types/sign';
import { TranslateView } from './components/TranslateView';
import { SignDictionaryView } from './components/SignDictionaryView';
import { PhraseBuilder } from './components/PhraseBuilder';
import { EmergencyMode } from './components/EmergencyMode';
import { TeachStudio } from './components/TeachStudio';
import { UpgradesPanel } from './components/UpgradesPanel';
import { Sparkles, Globe, ShieldAlert, ArrowRight, BookOpen, Layers } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<'translate' | 'dictionary' | 'phrase-builder' | 'emergency' | 'teach'>('translate');
  const [dialect, setDialect] = useState<SignDialect>('ASL');
  const [showUpgradesModal, setShowUpgradesModal] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* 
        TOP BAR CONTRACT:
        Zone 1: Single text element wordmark
        Zone 2: 4-6 clean text navigation links (single line, hover underlines)
        Zone 3: 1-2 primary actions
      */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          {/* Zone 1: Single text wordmark */}
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              setCurrentView('translate');
            }}
            className="text-lg font-extrabold tracking-tight text-white hover:text-indigo-300 transition-colors shrink-0"
          >
            SignBridge
          </a>

          {/* Zone 2: Clean text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-400">
            <button
              onClick={() => setCurrentView('translate')}
              className={`transition-colors hover:text-white pb-0.5 ${
                currentView === 'translate'
                  ? 'text-white border-b-2 border-indigo-500 font-semibold'
                  : 'text-slate-400'
              }`}
            >
              Translate
            </button>
            <button
              onClick={() => setCurrentView('dictionary')}
              className={`transition-colors hover:text-white pb-0.5 ${
                currentView === 'dictionary'
                  ? 'text-white border-b-2 border-indigo-500 font-semibold'
                  : 'text-slate-400'
              }`}
            >
              Sign Dictionary
            </button>
            <button
              onClick={() => setCurrentView('phrase-builder')}
              className={`transition-colors hover:text-white pb-0.5 ${
                currentView === 'phrase-builder'
                  ? 'text-white border-b-2 border-indigo-500 font-semibold'
                  : 'text-slate-400'
              }`}
            >
              Phrase Builder
            </button>
            <button
              onClick={() => setCurrentView('emergency')}
              className={`transition-colors hover:text-rose-400 pb-0.5 ${
                currentView === 'emergency'
                  ? 'text-rose-400 border-b-2 border-rose-500 font-semibold'
                  : 'text-slate-400'
              }`}
            >
              Emergency Mode
            </button>
            <button
              onClick={() => setCurrentView('teach')}
              className={`transition-colors hover:text-white pb-0.5 ${
                currentView === 'teach'
                  ? 'text-white border-b-2 border-indigo-500 font-semibold'
                  : 'text-slate-400'
              }`}
            >
              Teach & Practice
            </button>
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-2.5">
            {/* Dialect Selector */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl p-0.5 text-xs font-semibold">
              {(['ASL', 'ISL'] as const).map(d => (
                <button
                  key={d}
                  onClick={() => setDialect(d)}
                  className={`px-2.5 py-1 rounded-lg transition-colors ${
                    dialect === d
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>

            {/* Upgrades Studio Toggle Button */}
            <button
              onClick={() => setShowUpgradesModal(true)}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-850 text-indigo-300 hover:text-indigo-200 border border-indigo-500/30 text-xs font-semibold transition-all shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">Real Signs</span>
              <span>Upgrades</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Row */}
        <div className="md:hidden flex items-center justify-around px-2 py-2 border-t border-slate-800/80 bg-slate-950 overflow-x-auto text-xs font-medium text-slate-400">
          <button
            onClick={() => setCurrentView('translate')}
            className={`px-2 py-1 whitespace-nowrap ${currentView === 'translate' ? 'text-white font-bold' : ''}`}
          >
            Translate
          </button>
          <button
            onClick={() => setCurrentView('dictionary')}
            className={`px-2 py-1 whitespace-nowrap ${currentView === 'dictionary' ? 'text-white font-bold' : ''}`}
          >
            Dictionary
          </button>
          <button
            onClick={() => setCurrentView('phrase-builder')}
            className={`px-2 py-1 whitespace-nowrap ${currentView === 'phrase-builder' ? 'text-white font-bold' : ''}`}
          >
            Phrases
          </button>
          <button
            onClick={() => setCurrentView('emergency')}
            className={`px-2 py-1 whitespace-nowrap text-rose-400 ${currentView === 'emergency' ? 'font-bold' : ''}`}
          >
            Emergency
          </button>
          <button
            onClick={() => setCurrentView('teach')}
            className={`px-2 py-1 whitespace-nowrap ${currentView === 'teach' ? 'text-white font-bold' : ''}`}
          >
            Teach
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* View Switcher Container */}
        {currentView === 'translate' && <TranslateView />}
        {currentView === 'dictionary' && (
          <SignDictionaryView
            onAddToPhrase={(sign: SignEntry) => {
              setCurrentView('phrase-builder');
            }}
          />
        )}
        {currentView === 'phrase-builder' && <PhraseBuilder />}
        {currentView === 'emergency' && <EmergencyMode />}
        {currentView === 'teach' && <TeachStudio />}
      </main>

      {/* Upgrades Modal Dialog */}
      {showUpgradesModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            <UpgradesPanel
              currentDialect={dialect}
              onDialectChange={setDialect}
              onClose={() => setShowUpgradesModal(false)}
            />
          </div>
        </div>
      )}

      {/* Quiet Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950 py-8 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">SignBridge</span>
            <span>·</span>
            <span>Real Sign Language Architecture</span>
          </div>

          <div className="flex items-center gap-4">
            <button onClick={() => setCurrentView('translate')} className="hover:text-slate-300 transition-colors">
              Translator
            </button>
            <button onClick={() => setCurrentView('dictionary')} className="hover:text-slate-300 transition-colors">
              Dictionary
            </button>
            <button onClick={() => setCurrentView('emergency')} className="hover:text-rose-400 transition-colors">
              Emergency
            </button>
            <button onClick={() => setShowUpgradesModal(true)} className="hover:text-indigo-400 transition-colors">
              Upgrades & Engine
            </button>
          </div>

          <div className="font-mono text-[11px] text-slate-600">
            SignBridge v2.0 · ASL/ISL Authentic Standard
          </div>
        </div>
      </footer>
    </div>
  );
}

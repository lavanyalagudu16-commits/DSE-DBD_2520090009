import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { SIGN_DICTIONARY, parseSentenceToSigns, findSignByLabel } from '../data/signDictionary';
import { SignEntry } from '../types/sign';
import { SignPlayer } from './SignPlayer';
import { CameraGestureTracker } from './CameraGestureTracker';
import { RealSignVisual } from './RealSignVisual';
import { ArrowLeftRight, Mic, MicOff, Volume2, Sparkles, Send, RotateCcw, Camera, Copy, Check, Trash2, BookOpen } from 'lucide-react';

export const TranslateView: React.FC = () => {
  // 'word-to-sign' (text -> real sign animation) or 'sign-to-word' (camera/sign clicks -> text)
  const [mode, setMode] = useState<'word-to-sign' | 'sign-to-word'>('word-to-sign');
  const [inputText, setInputText] = useState('Hello friend please help');
  const [activeSigns, setActiveSigns] = useState<SignEntry[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [copied, setCopied] = useState(false);
  const [selectedPaletteCategory, setSelectedPaletteCategory] = useState<string>('greeting');

  // Live real-time translation as text changes
  const updateSigns = useCallback((text: string) => {
    const signs = parseSentenceToSigns(text);
    setActiveSigns(signs);
  }, []);

  // Update when inputText changes
  useEffect(() => {
    updateSigns(inputText);
  }, [inputText, updateSigns]);

  // Handle bidirectional swap
  const handleSwapDirections = () => {
    if (mode === 'word-to-sign') {
      setMode('sign-to-word');
    } else {
      setMode('word-to-sign');
      updateSigns(inputText);
    }
  };

  // Web Speech API Voice Dictation
  const toggleSpeechRecognition = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported on this browser.');
      return;
    }

    if (isListening) {
      setIsListening(false);
    } else {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => setIsListening(true);
        recognition.onresult = (e: any) => {
          const transcript = e.results[0][0].transcript;
          setInputText(transcript);
          updateSigns(transcript);
          setIsListening(false);
        };
        recognition.onerror = () => setIsListening(false);
        recognition.onend = () => setIsListening(false);

        recognition.start();
      } catch (err) {
        console.warn('Speech recognition start failed:', err);
        setIsListening(false);
      }
    }
  };

  // Speak aloud the current translation
  const handleSpeak = () => {
    if (!inputText.trim() || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(inputText);
    utterance.rate = 0.95;
    window.speechSynthesis.speak(utterance);
  };

  // Copy text to clipboard
  const handleCopy = () => {
    if (!inputText) return;
    navigator.clipboard.writeText(inputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Quick word addition when in Sign-to-Word mode
  const handleAddSignToText = (sign: SignEntry) => {
    setInputText(prev => (prev.trim() ? `${prev.trim()} ${sign.label}` : sign.label));
  };

  // Signs for the Sign-to-Word visual keyboard palette
  const paletteSigns = useMemo(() => {
    return SIGN_DICTIONARY.filter(s => {
      if (selectedPaletteCategory === 'all') return true;
      if (selectedPaletteCategory === 'alphabet') return s.category === 'alphabet';
      if (selectedPaletteCategory === 'greeting') return s.category === 'greeting';
      if (selectedPaletteCategory === 'emergency') return s.category === 'emergency';
      if (selectedPaletteCategory === 'daily') return s.category === 'daily';
      if (selectedPaletteCategory === 'social') return s.category === 'social';
      return true;
    });
  }, [selectedPaletteCategory]);

  return (
    <div className="space-y-6">
      {/* Top Direction Switcher Bar */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-indigo-400">
            <span className="uppercase tracking-wider">Two-Way Live Translation</span>
            <span className="text-slate-600">·</span>
            <span>Real Signs Engine 2.0</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight mt-0.5">
            {mode === 'word-to-sign' ? 'Word → Real Sign Translation' : 'Sign → Word Live Transcription'}
          </h2>
        </div>

        {/* Bidirectional Mode Switcher with Swap Button */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-xl">
            <button
              onClick={() => setMode('word-to-sign')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all ${
                mode === 'word-to-sign'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Word → Sign
            </button>
            <button
              onClick={() => setMode('sign-to-word')}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-all ${
                mode === 'sign-to-word'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sign → Word
            </button>
          </div>

          <button
            onClick={handleSwapDirections}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700"
            title="Swap translation direction"
            aria-label="Swap translation direction"
          >
            <ArrowLeftRight className="w-4 h-4 text-indigo-400" />
          </button>
        </div>
      </div>

      {mode === 'word-to-sign' ? (
        /* ==================== WORD TO SIGN VIEW ==================== */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Text Input (CSS Selector 1 Target) */}
          <div className="lg:col-span-5 bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono text-indigo-400 uppercase tracking-wider">
                  Type Words to Translate
                </span>
                <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  Live instant translation
                </span>
              </div>

              {/* Textarea for Word-to-Sign Input (Selected by User) */}
              <div className="relative">
                <textarea
                  value={inputText}
                  onChange={e => {
                    setInputText(e.target.value);
                    updateSigns(e.target.value);
                  }}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      updateSigns(inputText);
                    }
                  }}
                  placeholder="Type any word or phrase (e.g. Hello, Thank You, Doctor, Water, Mother, Happy, Help)..."
                  rows={5}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-indigo-500 rounded-xl p-4 text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500/50 resize-none font-medium leading-relaxed shadow-inner"
                />

                {/* Floating controls inside textarea */}
                <div className="absolute bottom-3 right-3 flex items-center gap-2">
                  <button
                    onClick={toggleSpeechRecognition}
                    className={`p-2 rounded-lg transition-colors ${
                      isListening
                        ? 'bg-rose-600 text-white animate-pulse'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white'
                    }`}
                    title={isListening ? 'Listening...' : 'Voice dictation'}
                    aria-label="Voice input"
                  >
                    {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={() => updateSigns(inputText)}
                    className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/30 flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Translate</span>
                  </button>
                </div>
              </div>

              {/* Quick Preset Word Chips */}
              <div className="pt-2 border-t border-slate-800/80">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-medium text-slate-500">Quick sign phrases:</span>
                  <button
                    onClick={() => {
                      setInputText('');
                      setActiveSigns([]);
                    }}
                    className="text-[10px] text-slate-500 hover:text-rose-400 transition-colors"
                  >
                    Clear text
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {[
                    'Hello friend',
                    'Thank you',
                    'Please help me',
                    'Where is water',
                    'I need doctor',
                    'Mother and father',
                    'Today I am happy',
                    'Stop'
                  ].map(phrase => (
                    <button
                      key={phrase}
                      onClick={() => {
                        setInputText(phrase);
                        updateSigns(phrase);
                      }}
                      className="px-2.5 py-1 text-xs rounded-lg bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800/90 transition-colors"
                    >
                      {phrase}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Translation Stats Card */}
            <div className="mt-4 p-3.5 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-400 space-y-1.5">
              <div className="flex justify-between items-center">
                <span>Recognized Real Signs:</span>
                <span className="font-mono text-indigo-400 font-bold">{activeSigns.length} signs</span>
              </div>
              <div className="flex justify-between items-center">
                <span>Natural Sign Sequence:</span>
                <span className="font-semibold text-emerald-400">Continuous 30 FPS Vector Flow</span>
              </div>
              <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1 border-t border-slate-800/60">
                <span>Fingerspelling Fallback:</span>
                <span>Active for names & loan words</span>
              </div>
            </div>
          </div>

          {/* Right Column: Real Sign Sequence Output (CSS Selector 2 Target) */}
          <div className="lg:col-span-7 bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-4">
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
                <div>
                  <span className="text-xs font-mono uppercase text-indigo-400">Visual Real Sign Player</span>
                  <h3 className="text-base font-bold text-white tracking-tight">
                    {inputText.trim() ? `"${inputText}"` : 'Enter words on the left to see signs'}
                  </h3>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleSpeak}
                    disabled={!inputText.trim()}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
                    title="Speak text aloud"
                  >
                    <Volume2 className="w-4 h-4 text-indigo-400" />
                  </button>
                  <button
                    onClick={handleCopy}
                    disabled={!inputText.trim()}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
                    title="Copy text"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Sequence Sign Player */}
            {activeSigns.length > 0 ? (
              <div className="space-y-4">
                <SignPlayer
                  signs={activeSigns}
                  sentenceText={inputText}
                  autoPlay={true}
                />

                {/* Individual Real Sign Breakdown Tiles */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-mono uppercase text-slate-400">All Signs in Sequence</span>
                    <span className="text-[11px] text-slate-500">{activeSigns.length} total</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    {activeSigns.map((sign, idx) => (
                      <div
                        key={`${sign.id}-${idx}`}
                        className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 flex flex-col items-center text-center shadow-sm hover:border-indigo-500/50 transition-colors"
                      >
                        <div className="scale-75 -my-3">
                          <RealSignVisual
                            sign={sign}
                            size="sm"
                            showControls={false}
                            showMotionArrows={false}
                          />
                        </div>
                        <span className="font-bold text-xs text-white mt-2 truncate w-full">
                          {sign.isFingerspelled ? `Letter "${sign.label}"` : sign.label}
                        </span>
                        <span className="text-[10px] text-slate-400 truncate w-full">
                          {sign.sourceWord ? sign.sourceWord : sign.category}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-16 text-center text-slate-500 border border-dashed border-slate-800 rounded-xl space-y-2">
                <Sparkles className="w-8 h-8 mx-auto text-slate-600 animate-pulse" />
                <p className="text-sm font-semibold text-slate-400">No words entered yet</p>
                <p className="text-xs text-slate-500">Type any English sentence or click an example on the left to see real sign animations.</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* ==================== SIGN TO WORD VIEW ==================== */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Live Camera Gesture Tracker */}
          <div className="lg:col-span-7">
            <CameraGestureTracker
              onSignRecognized={(sign: SignEntry) => {
                setInputText(prev => (prev.trim() ? `${prev.trim()} ${sign.label}` : sign.label));
              }}
            />
          </div>

          {/* Right Column: Visual Sign Keyboard & Transcribed Sentence */}
          <div className="lg:col-span-5 bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl">
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-xs font-mono uppercase text-indigo-400">Click Signs → Form Sentence</span>
                <span className="text-[11px] text-slate-400">Visual Sign Keyboard</span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Click any real sign below or use the camera on the left to transcribe signs directly into text.
              </p>
            </div>

            {/* Category Filter for Sign Palette */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1">
              {[
                { id: 'greeting', label: 'Greetings' },
                { id: 'emergency', label: 'Emergency' },
                { id: 'daily', label: 'Daily Life' },
                { id: 'social', label: 'Family & Social' },
                { id: 'alphabet', label: 'Alphabet' }
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedPaletteCategory(cat.id)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                    selectedPaletteCategory === cat.id
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-950 text-slate-400 hover:text-white'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Clickable Real Sign Tiles */}
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-64 overflow-y-auto pr-1">
              {paletteSigns.map(sign => (
                <button
                  key={sign.id}
                  onClick={() => handleAddSignToText(sign)}
                  className="p-2 rounded-xl bg-slate-950 hover:bg-indigo-950/60 border border-slate-800 hover:border-indigo-500 text-center transition-all group flex flex-col items-center"
                >
                  <div className="scale-65 -my-4">
                    <RealSignVisual
                      sign={sign}
                      size="sm"
                      showControls={false}
                      showMotionArrows={false}
                    />
                  </div>
                  <span className="font-bold text-[11px] text-white group-hover:text-indigo-300 mt-2 truncate w-full">
                    {sign.label}
                  </span>
                </button>
              ))}
            </div>

            {/* Transcribed English Output Box */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-mono uppercase text-indigo-400">Transcribed English Output</span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleSpeak}
                    disabled={!inputText.trim()}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
                    title="Speak transcribed sentence"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                  </button>
                  <button
                    onClick={handleCopy}
                    disabled={!inputText.trim()}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 disabled:opacity-40 transition-colors"
                    title="Copy text"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => setInputText('')}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/50 text-slate-400 hover:text-rose-300 transition-colors"
                    title="Clear"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <textarea
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="Transcribed words will appear here as you sign or click..."
                rows={3}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-white text-sm placeholder-slate-600 focus:outline-none resize-none font-medium leading-relaxed"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

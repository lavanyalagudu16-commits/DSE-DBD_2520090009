import React, { useState } from 'react';
import { SIGN_DICTIONARY } from '../data/signDictionary';
import { SignEntry, GesturePattern, MotionType } from '../types/sign';
import { RealSignVisual } from './RealSignVisual';
import { CameraGestureTracker } from './CameraGestureTracker';
import { Award, Sparkles, CheckCircle2, ChevronRight, Plus, BookOpen, Layers, Flame } from 'lucide-react';

export const TeachStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'practice' | 'teach'>('practice');

  // Practice State
  const practiceList = SIGN_DICTIONARY.filter(s => s.category === 'alphabet' || s.category === 'greeting');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [xp, setXp] = useState(150);
  const [streak, setStreak] = useState(3);
  const [hasCompletedCurrent, setHasCompletedCurrent] = useState(false);

  const currentSign = practiceList[currentIndex % practiceList.length];

  // Custom Sign Creation Form State
  const [customLabel, setCustomLabel] = useState('');
  const [customCategory, setCustomCategory] = useState<'greeting' | 'daily' | 'social'>('daily');
  const [customHandshape, setCustomHandshape] = useState('Open Palm / Custom Arc');
  const [customMovement, setCustomMovement] = useState('Horizontal sweep');
  const [customMotionType, setCustomMotionType] = useState<MotionType>('sweep-forward');
  const [customThumb, setCustomThumb] = useState(1);
  const [customIndex, setCustomIndex] = useState(1);
  const [customMiddle, setCustomMiddle] = useState(0);
  const [customRing, setCustomRing] = useState(0);
  const [customPinky, setCustomPinky] = useState(0);

  const [customSignsList, setCustomSignsList] = useState<SignEntry[]>([]);
  const [creationSuccess, setCreationSuccess] = useState(false);

  // Called when camera tracker recognizes a gesture
  const handleRecognized = (sign: SignEntry) => {
    if (sign.id === currentSign.id && !hasCompletedCurrent) {
      setHasCompletedCurrent(true);
      setXp(prev => prev + 50);
      setStreak(prev => prev + 1);
    }
  };

  const handleNextChallenge = () => {
    setHasCompletedCurrent(false);
    setCurrentIndex(prev => prev + 1);
  };

  const handleSaveCustomSign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customLabel.trim()) return;

    const newSign: SignEntry = {
      id: `custom-${Date.now()}`,
      label: customLabel.trim(),
      category: customCategory,
      handshape: customHandshape,
      palmOrientation: 'Facing forward',
      location: 'Chest height',
      movement: customMovement,
      description: `Custom sign trained for "${customLabel.trim()}" with custom handshape configuration.`,
      tips: 'Ensure crisp articulation of finger positions.',
      dialect: 'ASL',
      pattern: {
        thumb: customThumb,
        index: customIndex,
        middle: customMiddle,
        ring: customRing,
        pinky: customPinky,
        palmFacing: 'outward'
      },
      twoHanded: false,
      motionType: customMotionType
    };

    setCustomSignsList(prev => [newSign, ...prev]);
    setCreationSuccess(true);
    setCustomLabel('');
    setTimeout(() => setCreationSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-indigo-400">
            <span className="uppercase tracking-wider">Practice & AI Training Suite</span>
            <span className="text-slate-600">·</span>
            <span>Real-Time Feedback & Model Tuning</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">Teach the AI & Practice Studio</h2>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-950 border border-slate-800 rounded-xl">
          <button
            onClick={() => setActiveTab('practice')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'practice'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Practice Flashcards
          </button>
          <button
            onClick={() => setActiveTab('teach')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors ${
              activeTab === 'teach'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Train Custom Sign
          </button>
        </div>
      </div>

      {activeTab === 'practice' ? (
        <div className="space-y-6">
          {/* XP & Streak Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-900 rounded-xl border border-slate-800 p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 font-medium">Practice Streak</span>
                <p className="text-lg font-bold text-white font-mono">{streak} signs</p>
              </div>
            </div>

            <div className="bg-slate-900 rounded-xl border border-slate-800 p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 font-medium">Experience Points</span>
                <p className="text-lg font-bold text-white font-mono">{xp} XP</p>
              </div>
            </div>

            <div className="bg-slate-900 rounded-xl border border-slate-800 p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 font-medium">Challenge #</span>
                <p className="text-lg font-bold text-white font-mono">{currentIndex + 1} of {practiceList.length}</p>
              </div>
            </div>

            <div className="bg-slate-900 rounded-xl border border-slate-800 p-3.5 flex items-center gap-3">
              <div className="p-2 rounded-lg bg-sky-500/20 text-sky-400 border border-sky-500/30">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] text-slate-500 font-medium">Target Sign</span>
                <p className="text-lg font-bold text-white truncate">{currentSign.label}</p>
              </div>
            </div>
          </div>

          {/* Interactive Dual View: Goal Reference on Left, Live Camera / Simulator on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Target Reference Card */}
            <div className="lg:col-span-5 bg-slate-900 rounded-2xl border border-slate-800 p-5 flex flex-col items-center">
              <div className="w-full flex items-center justify-between pb-2 border-b border-slate-800 mb-3">
                <span className="text-xs uppercase font-mono text-indigo-400">Target Sign To Match</span>
                <span className="text-xs text-slate-400 capitalize">{currentSign.category}</span>
              </div>

              <div className="text-center mb-2">
                <h3 className="text-3xl font-extrabold text-white tracking-tight">{currentSign.label}</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-xs">{currentSign.description}</p>
              </div>

              <div className="my-2">
                <RealSignVisual
                  key={currentSign.id}
                  sign={currentSign}
                  size="md"
                  showControls={false}
                  showMotionArrows={true}
                />
              </div>

              <div className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-400 mt-3 space-y-1">
                <p><span className="text-slate-300 font-semibold">Handshape:</span> {currentSign.handshape}</p>
                <p><span className="text-slate-300 font-semibold">Tip:</span> {currentSign.tips}</p>
              </div>

              {/* Success Notification & Next Button */}
              {hasCompletedCurrent && (
                <div className="w-full mt-4 p-3 bg-emerald-950/80 border border-emerald-600/80 rounded-xl text-center space-y-2 animate-bounce">
                  <p className="text-xs font-bold text-emerald-300 flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Pose Matched! +50 XP Earned!</span>
                  </p>
                  <button
                    onClick={handleNextChallenge}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-1 shadow-md shadow-emerald-600/30"
                  >
                    <span>Next Practice Sign</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Live Camera Gesture Tracker for Practice */}
            <div className="lg:col-span-7">
              <CameraGestureTracker
                onSignRecognized={handleRecognized}
                targetSignForPractice={currentSign}
              />
            </div>
          </div>
        </div>
      ) : (
        /* Teach Custom Sign Form */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-5">
            <div>
              <h3 className="text-lg font-bold text-white tracking-tight">Teach a New Gesture</h3>
              <p className="text-xs text-slate-400">
                Define the finger configuration, movement vector, and linguistic metadata to train SignBridge's local recognition memory.
              </p>
            </div>

            {creationSuccess && (
              <div className="p-3 bg-emerald-950/80 border border-emerald-600/80 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>New custom sign successfully registered and added to local dictionary!</span>
              </div>
            )}

            <form onSubmit={handleSaveCustomSign} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Sign Label / Word *</label>
                  <input
                    type="text"
                    required
                    value={customLabel}
                    onChange={e => setCustomLabel(e.target.value)}
                    placeholder="e.g. Coffee, Bravo, Emergency Stop"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
                  <select
                    value={customCategory}
                    onChange={e => setCustomCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="daily">Daily Life</option>
                    <option value="greeting">Greeting</option>
                    <option value="social">Social</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Motion Movement Type</label>
                <select
                  value={customMotionType}
                  onChange={e => setCustomMotionType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="static">Static Hold</option>
                  <option value="sweep-forward">Sweep Forward Arc</option>
                  <option value="tap">Tap Twice</option>
                  <option value="circle">Circular Rub</option>
                  <option value="wave">Wave Side-to-Side</option>
                  <option value="open-close">Open & Close</option>
                </select>
              </div>

              {/* Finger Pattern Sliders */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <span className="text-xs font-medium text-slate-300 block">Finger Joint Pose Configuration</span>
                {[
                  { label: 'Thumb', val: customThumb, setVal: setCustomThumb },
                  { label: 'Index', val: customIndex, setVal: setCustomIndex },
                  { label: 'Middle', val: customMiddle, setVal: setCustomMiddle },
                  { label: 'Ring', val: customRing, setVal: setCustomRing },
                  { label: 'Pinky', val: customPinky, setVal: setCustomPinky }
                ].map(f => (
                  <div key={f.label} className="flex items-center justify-between gap-3 text-xs">
                    <span className="w-14 text-slate-400 font-medium">{f.label}</span>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={f.val}
                      onChange={e => f.setVal(parseFloat(e.target.value))}
                      className="flex-1 accent-indigo-500 h-1.5 bg-slate-800 rounded cursor-pointer"
                    />
                    <span className="w-12 text-right font-mono text-slate-400">
                      {f.val > 0.6 ? 'Open' : f.val > 0.2 ? 'Curved' : 'Fold'}
                    </span>
                  </div>
                ))}
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
              >
                <Plus className="w-4 h-4" />
                <span>Save & Train Sign Model</span>
              </button>
            </form>
          </div>

          {/* Right Column: Custom Trained Signs Catalog */}
          <div className="lg:col-span-5 bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-4">
            <h3 className="text-lg font-bold text-white tracking-tight">Trained Sign Library</h3>
            {customSignsList.length > 0 ? (
              <div className="space-y-3">
                {customSignsList.map(sign => (
                  <div key={sign.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3">
                    <RealSignVisual
                      sign={sign}
                      size="sm"
                      showControls={false}
                      showMotionArrows={false}
                    />
                    <div>
                      <h4 className="font-bold text-sm text-white">{sign.label}</h4>
                      <p className="text-[11px] text-indigo-400 capitalize">{sign.category} · {sign.motionType}</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">{sign.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center text-slate-500 border border-dashed border-slate-800 rounded-xl space-y-2">
                <BookOpen className="w-6 h-6 mx-auto text-slate-600" />
                <p className="text-xs">No custom gestures trained yet.</p>
                <p className="text-[11px] text-slate-500">Configure a handshape on the left to add a custom sign.</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

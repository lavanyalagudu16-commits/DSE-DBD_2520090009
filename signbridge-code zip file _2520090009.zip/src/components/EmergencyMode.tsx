import React, { useState, useEffect } from 'react';
import { ShieldAlert, Volume2, VolumeX, AlertTriangle, PhoneCall, HeartPulse, Sparkles, Flame, Eye, User, Stethoscope } from 'lucide-react';
import { SIGN_DICTIONARY } from '../data/signDictionary';
import { RealSignVisual } from './RealSignVisual';
import { SignEntry } from '../types/sign';

export const EmergencyMode: React.FC = () => {
  const emergencySignIds = [
    'emerg-help',
    'emerg-doctor',
    'emerg-pain',
    'emerg-breathe',
    'emerg-police',
    'emerg-fire',
    'emerg-allergy',
    'emerg-medicine',
    'daily-water'
  ];

  const emergencySigns = emergencySignIds
    .map(id => SIGN_DICTIONARY.find(s => s.id === id))
    .filter(Boolean) as SignEntry[];

  const [activeSign, setActiveSign] = useState<SignEntry>(emergencySigns[0]);
  const [isBeaconActive, setIsBeaconActive] = useState(false);
  const [isAlarmPlaying, setIsAlarmPlaying] = useState(false);
  const [audioCtx, setAudioCtx] = useState<AudioContext | null>(null);

  // High contrast beacon flashing effect
  useEffect(() => {
    if (!isBeaconActive) return;
    const interval = setInterval(() => {
      document.body.classList.toggle('emergency-flash');
    }, 500);
    return () => {
      clearInterval(interval);
      document.body.classList.remove('emergency-flash');
    };
  }, [isBeaconActive]);

  // Audio alarm generator using Web Audio API
  const toggleAlarm = () => {
    if (isAlarmPlaying) {
      if (audioCtx) {
        audioCtx.close();
        setAudioCtx(null);
      }
      setIsAlarmPlaying(false);
    } else {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        // Frequency sweep up and down
        let t = ctx.currentTime;
        for (let i = 0; i < 30; i++) {
          osc.frequency.setValueAtTime(850, t);
          osc.frequency.exponentialRampToValueAtTime(500, t + 0.3);
          t += 0.6;
        }

        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();

        setAudioCtx(ctx);
        setIsAlarmPlaying(true);
      } catch (e) {
        console.warn('Audio context blocked:', e);
      }
    }
  };

  // Speak aloud emergency announcement
  const speakEmergency = (sign: SignEntry) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(`Emergency announcement: ${sign.label}. ${sign.description}`);
      utterance.rate = 0.95;
      utterance.volume = 1;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className={`space-y-6 transition-all duration-300 ${isBeaconActive ? 'ring-4 ring-rose-500/80 rounded-3xl p-1' : ''}`}>
      {/* Top Banner Alert Bar */}
      <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-rose-950 border border-rose-800/80 rounded-2xl p-5 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-xl bg-rose-600/30 text-rose-400 border border-rose-500/40">
              <ShieldAlert className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-rose-400 uppercase tracking-wider">
                <span>Critical Life-Safety Protocol</span>
                <span className="text-slate-600">·</span>
                <span>Immediate Real Sign Assistance</span>
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight">Emergency Distress Mode</h2>
            </div>
          </div>

          {/* Action buttons: Siren & Flashing Beacon */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsBeaconActive(!isBeaconActive)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wide transition-all ${
                isBeaconActive
                  ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/40 animate-pulse'
                  : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700'
              }`}
            >
              <Eye className="w-4 h-4" />
              <span>{isBeaconActive ? 'Beacon Active' : 'Flash Beacon'}</span>
            </button>

            <button
              onClick={toggleAlarm}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wide transition-all ${
                isAlarmPlaying
                  ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/40 animate-pulse'
                  : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700'
              }`}
            >
              {isAlarmPlaying ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span>{isAlarmPlaying ? 'Stop Siren' : 'Play Siren'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Focus: Large Real Sign Visualizer for Current Distress */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Real Sign Visual */}
        <div className="lg:col-span-7 bg-slate-900 rounded-2xl border border-rose-900/40 p-6 flex flex-col items-center shadow-xl">
          <div className="w-full flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <span className="text-xs font-mono uppercase text-rose-400">Current Distress Sign</span>
              <h3 className="text-3xl font-extrabold text-white tracking-tight mt-0.5">{activeSign.label}</h3>
            </div>
            <button
              onClick={() => speakEmergency(activeSign)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold uppercase transition-all shadow-md shadow-rose-600/30"
            >
              <Volume2 className="w-4 h-4" />
              <span>Broadcast Voice</span>
            </button>
          </div>

          {/* Visual animation stage */}
          <div className="my-4">
            <RealSignVisual
              key={activeSign.id}
              sign={activeSign}
              size="hero"
              showControls={true}
              showMotionArrows={true}
              autoPlay={true}
            />
          </div>

          {/* Instructions for First Responder */}
          <div className="w-full bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <span className="font-semibold text-rose-300">How to perform:</span>
              <span>{activeSign.description}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-400">
              <span className="font-semibold text-rose-300">Target Location:</span>
              <span>{activeSign.location}</span>
            </div>
          </div>
        </div>

        {/* Right Column: High-Touch Emergency Sign Grid */}
        <div className="lg:col-span-5 space-y-4">
          <h4 className="text-sm font-bold text-slate-300 uppercase font-mono tracking-wider">
            One-Touch Emergency Signs
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2.5">
            {emergencySigns.map(sign => {
              const isSelected = activeSign.id === sign.id;
              return (
                <button
                  key={sign.id}
                  onClick={() => {
                    setActiveSign(sign);
                    speakEmergency(sign);
                  }}
                  className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-rose-950/80 border-rose-600 ring-2 ring-rose-500/40 shadow-lg'
                      : 'bg-slate-900 border-slate-800 hover:border-slate-750 hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${isSelected ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-300'}`}>
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-sm text-white block">{sign.label}</span>
                      <span className="text-[11px] text-slate-400 capitalize">{sign.movement}</span>
                    </div>
                  </div>

                  <span className={`text-xs font-semibold px-2 py-1 rounded-md ${
                    isSelected ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {isSelected ? 'Active' : 'Show Sign'}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick Medical Card Info */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase font-mono">
              <User className="w-4 h-4 text-indigo-400" />
              <span>Universal Medical Alert Profile</span>
            </div>
            <div className="space-y-1.5 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">Communication:</span>
                <span className="font-semibold text-indigo-300">Deaf / Hard of Hearing (ASL/ISL)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80">
                <span className="text-slate-500">Emergency Number:</span>
                <span className="font-semibold text-rose-300">Dial 911 / Text-to-911</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Special Notes:</span>
                <span className="font-medium text-slate-300">Please provide sign language interpreter or text notes.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { SignEntry, MotionType } from '../types/sign';
import { Play, Pause, RotateCcw, Eye, ArrowUpRight, ShieldAlert, Sparkles } from 'lucide-react';

interface RealSignVisualProps {
  sign: SignEntry;
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showControls?: boolean;
  showMotionArrows?: boolean;
  interactive?: boolean;
  playbackSpeed?: number;
  autoPlay?: boolean;
  highlightJoints?: boolean;
}

export const RealSignVisual: React.FC<RealSignVisualProps> = ({
  sign,
  size = 'md',
  showControls = true,
  showMotionArrows = true,
  interactive = true,
  playbackSpeed = 1,
  autoPlay = true,
  highlightJoints = false
}) => {
  const [isPlaying, setIsPlaying] = useState(autoPlay);
  const [animationPhase, setAnimationPhase] = useState(0); // 0 to 1
  const [showJoints, setShowJoints] = useState(highlightJoints);
  const [activeStep, setActiveStep] = useState<1 | 2 | 3>(2);

  // Animation loop for dynamic movements
  useEffect(() => {
    if (!isPlaying) return;
    let animId: number;
    let startTime: number | null = null;
    const duration = (2000 / playbackSpeed);

    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = (elapsed % duration) / duration;
      setAnimationPhase(progress);
      animId = requestAnimationFrame(step);
    };

    animId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, playbackSpeed]);

  const p = sign.pattern;
  const isTwoHanded = sign.twoHanded;

  // Dimensional scale
  const dimensions = {
    sm: { width: 140, height: 140, viewBox: '0 0 200 200' },
    md: { width: 220, height: 220, viewBox: '0 0 200 200' },
    lg: { width: 320, height: 320, viewBox: '0 0 220 220' },
    hero: { width: 440, height: 400, viewBox: '0 0 240 220' }
  }[size];

  // Calculate motion offset based on motionType and animationPhase
  const getMotionTransform = (motion: MotionType, phase: number) => {
    const sin = Math.sin(phase * Math.PI * 2);
    const bounce = Math.abs(Math.sin(phase * Math.PI * 2));
    switch (motion) {
      case 'sweep-forward':
        return `translate(${sin * 12}, ${-bounce * 10}) rotate(${sin * 4})`;
      case 'chin-forward':
        return `translate(${sin * 14}, ${sin * 10}) rotate(${sin * 6})`;
      case 'chest-rub':
      case 'circle':
        return `translate(${Math.cos(phase * Math.PI * 2) * 10}, ${Math.sin(phase * Math.PI * 2) * 10})`;
      case 'tap':
        return `translate(0, ${-bounce * 14})`;
      case 'bounce':
        return `translate(0, ${-bounce * 18})`;
      case 'wave':
        return `rotate(${sin * 14} 100 160)`;
      case 'pulse':
        return `translate(${sin * 6}, 0) scale(${1 + Math.abs(sin) * 0.04})`;
      case 'nod':
        return `rotate(${sin * 16} 100 180)`;
      case 'open-close':
        return `scale(${1 - bounce * 0.08})`;
      default:
        return 'translate(0, 0)';
    }
  };

  const transformStyle = isPlaying ? getMotionTransform(sign.motionType, animationPhase) : 'none';

  // Finger coordinates helper
  // Draw an authentic hand silhouette with palm and 5 articulate fingers
  const renderHand = (isSecondary = false) => {
    const thumbExt = isSecondary ? 0.3 : p.thumb;
    const indexExt = isSecondary ? (sign.id.includes('friend') || sign.id.includes('pain') ? 0.8 : 1) : p.index;
    const middleExt = isSecondary ? (sign.id.includes('doctor') ? 0.7 : 0) : p.middle;
    const ringExt = isSecondary ? 0 : p.ring;
    const pinkyExt = isSecondary ? 0 : p.pinky;

    // Special shapes:
    const isL = sign.label === 'L';
    const isC = sign.label === 'C' || sign.handshape.includes('C-');
    const isO = sign.label === 'O' || sign.label === '0';
    const isV = sign.label === 'V' || sign.label === '2';
    const isY = sign.label === 'Y';
    const isR = sign.label === 'R';
    const isX = sign.label === 'X';

    // Palm base center is around (100, 150)
    return (
      <g className="transition-all duration-300">
        {/* Palm Body */}
        <path
          d={
            isSecondary && (sign.id.includes('help') || sign.id.includes('stop') || sign.id.includes('good') || sign.id.includes('medicine'))
              ? "M 50 160 Q 50 140 100 135 Q 150 140 150 160 Q 140 185 100 185 Q 60 185 50 160 Z"
              : isC || isO
              ? "M 75 145 C 65 125 70 100 85 95 C 100 90 120 90 135 105 C 145 115 140 145 130 165 C 120 180 90 180 75 145 Z"
              : "M 70 145 Q 65 120 80 115 L 125 115 Q 140 120 135 150 Q 130 180 100 182 Q 72 180 70 145 Z"
          }
          fill="url(#palmGradient)"
          stroke="#4f46e5"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />

        {/* Natural palm contour line / thenar crease */}
        <path
          d="M 85 135 Q 100 145 115 140"
          stroke="#6366f1"
          strokeWidth="1.5"
          strokeLinecap="round"
          fill="none"
          opacity="0.6"
        />
        <path
          d="M 90 155 Q 105 160 120 152"
          stroke="#6366f1"
          strokeWidth="1.2"
          strokeLinecap="round"
          fill="none"
          opacity="0.4"
        />

        {/* THUMB */}
        {thumbExt > 0.6 ? (
          // Extended Thumb (like L, A, Y, 3, 5, 10, Help)
          <path
            d={
              isY
                ? "M 75 140 C 55 145 35 155 30 140 C 25 125 45 125 68 128 Z"
                : isL || thumbExt === 1
                ? "M 75 140 C 50 145 30 145 32 130 C 35 115 60 120 72 124 Z"
                : "M 72 145 C 55 138 52 118 60 112 C 70 108 76 122 75 135 Z"
            }
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
          />
        ) : thumbExt > 0.2 ? (
          // Semi-bent thumb (C, O, E, F)
          <path
            d="M 75 145 C 62 140 60 125 72 120 C 82 115 88 128 85 140 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
          />
        ) : (
          // Folded across palm (B, S, U, V)
          <path
            d="M 72 145 C 80 142 98 142 105 145 C 108 148 100 156 85 155 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
          />
        )}

        {/* INDEX FINGER */}
        {indexExt > 0.7 ? (
          // Fully Extended Index
          <path
            d={
              isX
                ? "M 78 116 C 76 95 80 80 90 85 C 95 90 88 105 87 116 Z"
                : isV
                ? "M 78 115 C 72 85 70 60 80 58 C 90 56 90 85 88 115 Z"
                : isR
                ? "M 80 115 C 82 85 88 60 96 58 C 102 56 96 85 88 115 Z"
                : "M 78 115 C 77 80 77 55 87 55 C 96 55 96 80 94 115 Z"
            }
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
        ) : indexExt > 0.3 ? (
          // Curled index (C, O, E)
          <path
            d="M 78 115 C 75 100 85 90 95 95 C 100 100 95 110 88 115 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
          />
        ) : (
          // Tucked in fist (A, S, I, Y)
          <path
            d="M 78 115 C 76 108 84 104 90 106 C 96 108 94 116 88 118 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2"
          />
        )}

        {/* MIDDLE FINGER */}
        {middleExt > 0.7 ? (
          <path
            d={
              isV
                ? "M 92 115 C 98 85 108 60 118 62 C 126 64 112 88 103 115 Z"
                : isR
                ? "M 90 115 C 85 85 78 62 86 60 C 94 58 98 85 102 115 Z"
                : "M 93 114 C 92 75 92 50 102 50 C 111 50 111 75 108 114 Z"
            }
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
        ) : middleExt > 0.3 ? (
          <path
            d="M 93 114 C 92 100 102 92 108 96 C 112 102 108 110 104 115 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
          />
        ) : (
          <path
            d="M 93 115 C 93 108 100 105 106 107 C 110 110 108 117 103 118 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2"
          />
        )}

        {/* RING FINGER */}
        {ringExt > 0.7 ? (
          <path
            d="M 107 115 C 107 80 108 55 117 55 C 126 55 125 80 122 115 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
        ) : ringExt > 0.3 ? (
          <path
            d="M 107 115 C 107 102 116 95 122 98 C 126 103 122 111 118 115 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
          />
        ) : (
          <path
            d="M 107 115 C 107 109 114 106 120 108 C 123 111 121 117 117 118 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2"
          />
        )}

        {/* PINKY FINGER */}
        {pinkyExt > 0.7 ? (
          <path
            d={
              isY
                ? "M 120 117 C 128 95 145 75 154 82 C 160 90 140 105 131 120 Z"
                : "M 121 118 C 122 88 124 68 132 68 C 140 68 138 88 134 118 Z"
            }
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
        ) : pinkyExt > 0.3 ? (
          <path
            d="M 121 118 C 122 105 130 98 135 102 C 139 106 135 114 130 118 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2.2"
          />
        ) : (
          <path
            d="M 121 118 C 121 112 127 109 132 111 C 135 113 133 119 129 120 Z"
            fill="url(#fingerGradient)"
            stroke="#4338ca"
            strokeWidth="2"
          />
        )}

        {/* WRIST ATTACHMENT */}
        <path
          d="M 82 178 L 80 205 L 122 205 L 120 178 Z"
          fill="url(#wristGradient)"
          stroke="#4338ca"
          strokeWidth="2.2"
        />

        {/* Joint Overlay Dots (if toggled) */}
        {showJoints && (
          <g className="animate-pulse">
            {/* Wrist */}
            <circle cx="100" cy="180" r="3.5" fill="#38bdf8" />
            {/* MCP Knuckles */}
            <circle cx="86" cy="116" r="3" fill="#818cf8" />
            <circle cx="100" cy="115" r="3" fill="#818cf8" />
            <circle cx="114" cy="116" r="3" fill="#818cf8" />
            <circle cx="127" cy="118" r="3" fill="#818cf8" />
            {/* Thumb CMC/MCP */}
            <circle cx="68" cy="144" r="3" fill="#38bdf8" />
            {/* Fingertips */}
            {indexExt > 0.7 && <circle cx="87" cy="57" r="3" fill="#34d399" />}
            {middleExt > 0.7 && <circle cx="102" cy="52" r="3" fill="#34d399" />}
            {ringExt > 0.7 && <circle cx="117" cy="57" r="3" fill="#34d399" />}
            {pinkyExt > 0.7 && <circle cx="132" cy="70" r="3" fill="#34d399" />}
          </g>
        )}
      </g>
    );
  };

  // Motion arrow vector renderer
  const renderMotionArrow = () => {
    if (!showMotionArrows) return null;
    const motion = sign.motionType;

    switch (motion) {
      case 'sweep-forward':
      case 'chin-forward':
        return (
          <g className="motion-indicator">
            <defs>
              <marker id="arrow-forward" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#38bdf8" />
              </marker>
            </defs>
            <path
              d="M 60 70 Q 100 30 160 55"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="3"
              strokeDasharray="6 4"
              markerEnd="url(#arrow-forward)"
              className="animate-pulse"
            />
            <text x="110" y="32" fill="#7dd3fc" fontSize="9" fontWeight="600" textAnchor="middle">
              Move forward
            </text>
          </g>
        );

      case 'chest-rub':
      case 'circle':
        return (
          <g className="motion-indicator">
            <defs>
              <marker id="arrow-circle" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#fbbf24" />
              </marker>
            </defs>
            <path
              d="M 100 80 A 35 35 0 1 1 95 80"
              fill="none"
              stroke="#fbbf24"
              strokeWidth="2.8"
              strokeDasharray="5 3"
              markerEnd="url(#arrow-circle)"
            />
            <text x="100" y="42" fill="#fde68a" fontSize="9" fontWeight="600" textAnchor="middle">
              Circular motion
            </text>
          </g>
        );

      case 'tap':
      case 'bounce':
        return (
          <g className="motion-indicator">
            <defs>
              <marker id="arrow-down" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
                <path d="M 0 0 L 10 5 L 0 10 z" fill="#34d399" />
              </marker>
            </defs>
            <path
              d="M 80 40 L 80 75"
              fill="none"
              stroke="#34d399"
              strokeWidth="3"
              markerEnd="url(#arrow-down)"
            />
            <path
              d="M 120 40 L 120 75"
              fill="none"
              stroke="#34d399"
              strokeWidth="3"
              markerEnd="url(#arrow-down)"
            />
            <text x="100" y="32" fill="#6ee7b7" fontSize="9" fontWeight="600" textAnchor="middle">
              Tap twice
            </text>
          </g>
        );

      case 'wave':
        return (
          <g className="motion-indicator">
            <path
              d="M 40 90 Q 55 75 70 90 T 100 90 T 130 90 T 160 90"
              fill="none"
              stroke="#f472b6"
              strokeWidth="2.5"
              strokeDasharray="4 3"
            />
            <text x="100" y="70" fill="#fbcfe8" fontSize="9" fontWeight="600" textAnchor="middle">
              Oscillate / wave
            </text>
          </g>
        );

      case 'pulse':
        return (
          <g className="motion-indicator">
            <circle cx="100" cy="110" r="60" fill="none" stroke="#ef4444" strokeWidth="2" strokeDasharray="4 4" className="animate-ping" opacity="0.4" />
            <text x="100" y="45" fill="#fca5a5" fontSize="9" fontWeight="600" textAnchor="middle">
              Rapid vibration
            </text>
          </g>
        );

      case 'open-close':
        return (
          <g className="motion-indicator">
            <path d="M 65 75 L 85 95" stroke="#a78bfa" strokeWidth="2.5" strokeDasharray="3 3" />
            <path d="M 135 75 L 115 95" stroke="#a78bfa" strokeWidth="2.5" strokeDasharray="3 3" />
            <text x="100" y="45" fill="#ddd6fe" fontSize="9" fontWeight="600" textAnchor="middle">
              Snap closed
            </text>
          </g>
        );

      default:
        return null;
    }
  };

  return (
    <div className="relative flex flex-col items-center select-none group">
      {/* SVG Canvas Stage */}
      <div className="relative rounded-2xl bg-gradient-to-b from-slate-900/90 via-slate-900/70 to-slate-950/90 border border-slate-800/80 p-2 shadow-inner overflow-hidden flex items-center justify-center">
        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b15_1px,transparent_1px),linear-gradient(to_bottom,#1e293b15_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />

        {/* Dialect and Mode tags */}
        <div className="absolute top-2.5 left-3 flex items-center gap-1.5 z-10 text-[11px] font-medium text-slate-400">
          <span className="text-indigo-400 font-semibold">{sign.dialect}</span>
          <span className="text-slate-600">·</span>
          <span>{sign.handshape.split('(')[0].trim()}</span>
        </div>

        {/* Real Sign Badge */}
        <div className="absolute top-2.5 right-3 flex items-center gap-1 z-10 text-[11px] text-emerald-400/90 bg-emerald-950/40 border border-emerald-800/40 px-2 py-0.5 rounded-md">
          <Sparkles className="w-3 h-3 text-emerald-400" />
          <span>Real Sign</span>
        </div>

        <svg
          width={dimensions.width}
          height={dimensions.height}
          viewBox={dimensions.viewBox}
          className="relative z-0 filter drop-shadow-md"
        >
          <defs>
            <linearGradient id="palmGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#312e81" />
              <stop offset="60%" stopColor="#1e1b4b" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
            <linearGradient id="fingerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#4338ca" />
              <stop offset="50%" stopColor="#3730a3" />
              <stop offset="100%" stopColor="#1e1b4b" />
            </linearGradient>
            <linearGradient id="wristGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#1e1b4b" />
              <stop offset="100%" stopColor="#090d16" />
            </linearGradient>
            <linearGradient id="secondaryPalmGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>
          </defs>

          {/* Secondary hand for two-handed signs */}
          {isTwoHanded && (
            <g transform="translate(10, 25) scale(0.9)" opacity="0.75">
              {renderHand(true)}
            </g>
          )}

          {/* Primary animated hand */}
          <g transform={transformStyle}>
            {renderHand(false)}
          </g>

          {/* Motion Indicators */}
          {renderMotionArrow()}
        </svg>

        {/* Step indicator footer on card */}
        <div className="absolute bottom-2 inset-x-3 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/60 pt-1.5">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500">Palm:</span>
            <span className="text-slate-300 font-medium capitalize">{sign.palmOrientation.split('/')[0]}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-slate-400 capitalize">{sign.motionType.replace('-', ' ')}</span>
          </div>
        </div>
      </div>

      {/* Interactive Controls Bar */}
      {showControls && (
        <div className="w-full mt-2 flex items-center justify-between px-1 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors"
              title={isPlaying ? 'Pause demonstration' : 'Play motion'}
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => {
                setAnimationPhase(0);
                setIsPlaying(true);
              }}
              className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors"
              title="Reset motion"
              aria-label="Reset"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setShowJoints(!showJoints)}
              className={`p-1.5 rounded-lg transition-colors ${
                showJoints ? 'bg-indigo-600 text-white' : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
              title="Toggle anatomical landmarks"
              aria-label="Joints"
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* 3-Step Guided Stage */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded-lg">
            <button
              onClick={() => {
                setActiveStep(1);
                setIsPlaying(false);
                setAnimationPhase(0);
              }}
              className={`px-2 py-0.5 text-[10px] font-medium rounded transition-colors ${
                activeStep === 1 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Shape
            </button>
            <button
              onClick={() => {
                setActiveStep(2);
                setIsPlaying(true);
              }}
              className={`px-2 py-0.5 text-[10px] font-medium rounded transition-colors ${
                activeStep === 2 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Move
            </button>
            <button
              onClick={() => {
                setActiveStep(3);
                setIsPlaying(false);
                setAnimationPhase(0.75);
              }}
              className={`px-2 py-0.5 text-[10px] font-medium rounded transition-colors ${
                activeStep === 3 ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Finish
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

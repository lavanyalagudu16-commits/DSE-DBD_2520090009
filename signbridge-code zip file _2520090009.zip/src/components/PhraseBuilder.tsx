import React, { useState } from 'react';
import { SignEntry } from '../types/sign';
import { SIGN_DICTIONARY, CATEGORIES, findSignByLabel } from '../data/signDictionary';
import { RealSignVisual } from './RealSignVisual';
import { SignPlayer } from './SignPlayer';
import { Plus, X, Play, Trash2, Sparkles, ArrowRight, Share2, Check } from 'lucide-react';

export const PhraseBuilder: React.FC = () => {
  const [selectedSigns, setSelectedSigns] = useState<SignEntry[]>([
    findSignByLabel('Please')!,
    findSignByLabel('Help')!,
    findSignByLabel('Friend')!
  ].filter(Boolean));

  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [exported, setExported] = useState(false);

  // Quick Preset Phrases
  const PRESET_PHRASES = [
    { label: 'Need Medical Help', signs: ['Help', 'Doctor', 'Pain'] },
    { label: 'Polite Greeting', signs: ['Hello', 'Friend', 'Thank You'] },
    { label: 'Ask for Restroom', signs: ['Where', 'Restroom / Bathroom', 'Please'] },
    { label: 'Ask for Water', signs: ['Water', 'Please', 'Thank You'] },
    { label: 'Emergency Warning', signs: ['Emergency', 'Police / Call 911', 'Stop'] }
  ];

  const handleApplyPreset = (signNames: string[]) => {
    const list = signNames.map(name => findSignByLabel(name)).filter(Boolean) as SignEntry[];
    setSelectedSigns(list);
    setIsPlaying(false);
  };

  const handleAddSign = (sign: SignEntry) => {
    setSelectedSigns(prev => [...prev, sign]);
  };

  const handleRemoveSign = (index: number) => {
    setSelectedSigns(prev => prev.filter((_, i) => i !== index));
  };

  const filteredSigns = SIGN_DICTIONARY.filter(s => {
    const matchesCat = activeCategory === 'all' || s.category === activeCategory;
    const matchesQuery = !searchQuery || s.label.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6">
        <div className="max-w-2xl space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono text-indigo-400">
            <span className="uppercase tracking-wider">Visual Sentence Constructor</span>
            <span className="text-slate-600">·</span>
            <span>Real Sign Sequence Animation</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">Phrase Builder</h2>
          <p className="text-sm text-slate-400 leading-relaxed">
            Assemble authentic sign language phrases word by word. Preview real anatomical hand transitions, adjust pacing, and play fluid sequences for conversation.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">Quick Phrases:</span>
          {PRESET_PHRASES.map(p => (
            <button
              key={p.label}
              onClick={() => handleApplyPreset(p.signs)}
              className="px-3 py-1 text-xs rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 font-medium transition-colors border border-slate-700/60"
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Sequence Timeline & Player */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <span className="text-xs font-mono text-indigo-400 uppercase">Constructed Timeline</span>
            <h3 className="text-lg font-bold text-white tracking-tight">
              {selectedSigns.length > 0
                ? selectedSigns.map(s => s.label).join(' → ')
                : 'Phrase is empty'}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {selectedSigns.length > 0 && (
              <>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-indigo-600/20"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isPlaying ? 'Close Sequence' : 'Play Sign Sequence'}</span>
                </button>
                <button
                  onClick={() => setSelectedSigns([])}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-300 transition-colors"
                  title="Clear phrase"
                  aria-label="Clear phrase"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Dynamic Player when playing */}
        {isPlaying && selectedSigns.length > 0 && (
          <div className="py-2">
            <SignPlayer
              signs={selectedSigns}
              autoPlay={true}
              onSignComplete={() => {}}
            />
          </div>
        )}

        {/* Horizontal Visual Sign Sequence Cards */}
        {selectedSigns.length > 0 ? (
          <div className="flex items-center gap-3 overflow-x-auto pb-3 pt-1">
            {selectedSigns.map((sign, index) => (
              <div
                key={`${sign.id}-${index}`}
                className="flex-shrink-0 relative group bg-slate-950 rounded-xl border border-slate-800 p-3 w-36 flex flex-col items-center shadow-md transition-all hover:border-indigo-500/50"
              >
                {/* Index badge */}
                <span className="absolute top-2 left-2 text-[10px] font-mono text-slate-500">
                  #{index + 1}
                </span>

                {/* Remove button */}
                <button
                  onClick={() => handleRemoveSign(index)}
                  className="absolute top-2 right-2 p-1 rounded-md bg-slate-800 hover:bg-rose-600 text-slate-400 hover:text-white transition-colors"
                  title="Remove from phrase"
                >
                  <X className="w-3 h-3" />
                </button>

                <div className="my-1 scale-90">
                  <RealSignVisual
                    sign={sign}
                    size="sm"
                    showControls={false}
                    showMotionArrows={false}
                  />
                </div>

                <div className="text-center mt-1 w-full">
                  <h4 className="text-sm font-bold text-white truncate">{sign.label}</h4>
                  <p className="text-[10px] text-slate-400 capitalize">{sign.category}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-10 text-center text-slate-500 border border-dashed border-slate-800 rounded-xl space-y-1">
            <p className="text-sm font-medium">Your sequence timeline is currently empty.</p>
            <p className="text-xs text-slate-500">Click on any sign from the catalog below to add it to your sentence.</p>
          </div>
        )}
      </div>

      {/* Sign Catalog / Picker */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-bold text-white tracking-tight">Add Signs to Sequence</h3>
            <p className="text-xs text-slate-400">Click any real sign card to insert it at the end of your sentence.</p>
          </div>

          {/* Search box */}
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search sign catalog..."
            className="w-full sm:w-64 bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Category Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat.id
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Real Sign Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {filteredSigns.map(sign => (
            <div
              key={sign.id}
              onClick={() => handleAddSign(sign)}
              className="bg-slate-950/80 hover:bg-slate-950 rounded-xl border border-slate-800/80 hover:border-indigo-500 p-2.5 flex flex-col items-center text-center cursor-pointer transition-all hover:scale-[1.02] group shadow-sm"
            >
              <div className="scale-75 -my-3">
                <RealSignVisual
                  sign={sign}
                  size="sm"
                  showControls={false}
                  showMotionArrows={false}
                />
              </div>

              <div className="mt-2 w-full">
                <h4 className="text-xs font-bold text-white group-hover:text-indigo-300 transition-colors truncate">
                  {sign.label}
                </h4>
                <div className="flex items-center justify-center gap-1 text-[10px] text-slate-500 mt-0.5">
                  <span className="capitalize">{sign.category}</span>
                </div>
              </div>

              <button
                onClick={e => {
                  e.stopPropagation();
                  handleAddSign(sign);
                }}
                className="mt-2 w-full py-1 rounded-lg bg-slate-800 group-hover:bg-indigo-600 text-slate-300 group-hover:text-white text-[11px] font-semibold transition-colors flex items-center justify-center gap-1"
              >
                <Plus className="w-3 h-3" />
                <span>Add</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

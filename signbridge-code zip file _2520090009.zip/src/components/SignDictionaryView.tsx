import React, { useState } from 'react';
import { SIGN_DICTIONARY, CATEGORIES, searchSigns } from '../data/signDictionary';
import { SignEntry } from '../types/sign';
import { RealSignVisual } from './RealSignVisual';
import { DictionaryModal } from './DictionaryModal';
import { Search, Filter, Sparkles, BookOpen, Volume2, ArrowUpRight } from 'lucide-react';

interface SignDictionaryViewProps {
  onAddToPhrase?: (sign: SignEntry) => void;
}

export const SignDictionaryView: React.FC<SignDictionaryViewProps> = ({ onAddToPhrase }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeModalSign, setActiveModalSign] = useState<SignEntry | null>(null);

  const signs = searchSigns(searchQuery, selectedCategory);

  return (
    <div className="space-y-6">
      {/* Top Hero Card */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="max-w-xl">
          <div className="flex items-center gap-2 text-xs font-mono text-indigo-400">
            <span className="uppercase tracking-wider">Authentic Lexicon</span>
            <span className="text-slate-600">·</span>
            <span>{SIGN_DICTIONARY.length} Real Signs Verified</span>
          </div>
          <h2 className="text-2xl font-extrabold text-white tracking-tight mt-0.5">Real Sign Language Dictionary</h2>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Browse authentic vector anatomical hand gestures. Every entry features exact handshapes, movement vectors, palm orientations, and step-by-step guidance.
          </p>
        </div>

        {/* Search Bar */}
        <div className="w-full md:w-72 relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by sign, handshape, movement..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2.5 border-b border-slate-800/80 scrollbar-thin">
        {CATEGORIES.map(cat => {
          const count = cat.id === 'all'
            ? SIGN_DICTIONARY.length
            : SIGN_DICTIONARY.filter(s => s.category === cat.id).length;
          const isSelected = selectedCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-2 border select-none ${
                isSelected
                  ? 'bg-indigo-600 text-white border-indigo-400/40 shadow-lg shadow-indigo-600/30 scale-[1.02]'
                  : 'bg-slate-900/90 text-slate-300 border-slate-800 hover:border-slate-700 hover:bg-slate-850 hover:text-white'
              }`}
            >
              <span>{cat.label}</span>
              <span className={`text-[11px] font-mono tabular-nums px-2 py-0.5 rounded-md font-bold transition-colors ${
                isSelected
                  ? 'bg-white/20 text-white'
                  : 'bg-slate-950/80 text-indigo-400 border border-slate-800'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Grid of Real Signs */}
      {signs.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {signs.map(sign => (
            <div
              key={sign.id}
              onClick={() => setActiveModalSign(sign)}
              className="bg-slate-900 hover:bg-slate-850 rounded-2xl border border-slate-800 hover:border-indigo-500/60 p-4 transition-all hover:scale-[1.01] cursor-pointer shadow-md group flex flex-col justify-between"
            >
              <div>
                {/* Header info */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-2">
                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors">
                      {sign.label}
                    </h3>
                    <span className="text-[11px] text-slate-400 capitalize">{sign.category}</span>
                  </div>
                  <span className="text-[10px] font-mono text-indigo-400 bg-indigo-950/60 border border-indigo-800/50 px-2 py-0.5 rounded">
                    {sign.dialect}
                  </span>
                </div>

                {/* Real Sign Visual Stage */}
                <div className="my-2 flex justify-center">
                  <RealSignVisual
                    sign={sign}
                    size="sm"
                    showControls={false}
                    showMotionArrows={true}
                    interactive={false}
                  />
                </div>

                {/* Details snippet */}
                <div className="text-[11px] text-slate-400 mt-2 space-y-1">
                  <p className="truncate">
                    <span className="text-slate-500">Shape: </span>{sign.handshape.split('(')[0]}
                  </p>
                  <p className="truncate">
                    <span className="text-slate-500">Move: </span>{sign.movement}
                  </p>
                </div>
              </div>

              {/* Action button */}
              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-indigo-400 font-semibold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                  <span>View Details</span>
                  <ArrowUpRight className="w-3 h-3" />
                </span>

                {onAddToPhrase && (
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      onAddToPhrase(sign);
                    }}
                    className="p-1 px-2 text-[10px] font-semibold bg-slate-800 hover:bg-indigo-600 text-slate-300 hover:text-white rounded-md transition-colors"
                  >
                    + Phrase
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-16 text-center text-slate-500 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
          <BookOpen className="w-8 h-8 mx-auto text-slate-600" />
          <p className="text-base font-semibold text-slate-300">No matching signs found</p>
          <p className="text-xs text-slate-500">Try adjusting your search query or switching categories.</p>
        </div>
      )}

      {/* Detailed Modal */}
      <DictionaryModal
        sign={activeModalSign}
        onClose={() => setActiveModalSign(null)}
        onAddToPhrase={onAddToPhrase}
      />
    </div>
  );
};

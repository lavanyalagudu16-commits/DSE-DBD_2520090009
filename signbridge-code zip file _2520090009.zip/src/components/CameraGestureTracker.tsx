import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Camera, CameraOff, Volume2, Sparkles, RefreshCw, Delete, Copy, Check, SlidersHorizontal, Eye, Sun, Target, Zap } from 'lucide-react';
import { SIGN_DICTIONARY } from '../data/signDictionary';
import { GesturePattern, SignEntry } from '../types/sign';
import { RealSignVisual } from './RealSignVisual';

interface CameraGestureTrackerProps {
  onSignRecognized?: (sign: SignEntry) => void;
  targetSignForPractice?: SignEntry | null;
}

export const CameraGestureTracker: React.FC<CameraGestureTrackerProps> = ({
  onSignRecognized,
  targetSignForPractice
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const analysisCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [useSimulator, setUseSimulator] = useState(false);

  // Vision detection settings
  const [sensitivity, setSensitivity] = useState<'normal' | 'high' | 'dim'>('normal');
  const [showSkeleton, setShowSkeleton] = useState(true);
  const [handDetected, setHandDetected] = useState(false);

  // Live measured finger extension states (0 to 1)
  const [liveFingers, setLiveFingers] = useState({
    thumb: 0,
    index: 0,
    middle: 0,
    ring: 0,
    pinky: 0
  });

  // Virtual hand simulation sliders
  const [simThumb, setSimThumb] = useState(0.8);
  const [simIndex, setSimIndex] = useState(0);
  const [simMiddle, setSimMiddle] = useState(0);
  const [simRing, setSimRing] = useState(0);
  const [simPinky, setSimPinky] = useState(0);

  // Recognition state
  const [currentMatch, setCurrentMatch] = useState<{ sign: SignEntry; confidence: number } | null>(null);
  const [accumulatedText, setAccumulatedText] = useState('');
  const [copied, setCopied] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Filtered finger states for smoothing across frames
  const smoothedFingersRef = useRef({ thumb: 0, index: 0, middle: 0, ring: 0, pinky: 0 });
  const lastMatchTimestampRef = useRef<number>(0);

  // Match pattern against dictionary with Euclidean & Cosine distance
  const matchPattern = useCallback((currentPattern: GesturePattern) => {
    let bestSign: SignEntry | null = null;
    let highestScore = -1;

    for (const sign of SIGN_DICTIONARY) {
      const p = sign.pattern;
      // Calculate weighted Euclidean similarity
      const dThumb = Math.abs(currentPattern.thumb - p.thumb);
      const dIndex = Math.abs(currentPattern.index - p.index);
      const dMiddle = Math.abs(currentPattern.middle - p.middle);
      const dRing = Math.abs(currentPattern.ring - p.ring);
      const dPinky = Math.abs(currentPattern.pinky - p.pinky);

      const totalDist = (dThumb * 1.3) + (dIndex * 1.5) + (dMiddle * 1.3) + (dRing * 1.0) + (dPinky * 1.1);
      const similarity = Math.max(0, 100 - (totalDist * 18));

      if (similarity > highestScore) {
        highestScore = similarity;
        bestSign = sign;
      }
    }

    if (bestSign && highestScore >= 68) {
      const confidence = Math.min(99, Math.round(highestScore));
      setCurrentMatch({ sign: bestSign, confidence });
      onSignRecognized?.(bestSign);
    } else {
      setCurrentMatch(null);
    }
  }, [onSignRecognized]);

  // Handle camera start
  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        setIsCameraActive(true);
        setUseSimulator(false);
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError(err.message || 'Camera permission denied or camera unavailable. Switched to Interactive Hand Simulator.');
      setIsCameraActive(false);
      setUseSimulator(true);
    }
  };

  // Handle camera stop
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
    setHandDetected(false);
  };

  // Optical Hand & Skin Pixel Computer Vision Engine
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    const video = videoRef.current;

    // Create low-res analysis canvas (160x120) for 60fps computer vision processing
    if (!analysisCanvasRef.current) {
      const aCanvas = document.createElement('canvas');
      aCanvas.width = 160;
      aCanvas.height = 120;
      analysisCanvasRef.current = aCanvas;
    }
    const aCanvas = analysisCanvasRef.current;
    const aCtx = aCanvas?.getContext('2d', { willReadFrequently: true });

    let frameCount = 0;

    const processVisionFrame = (timestamp: number) => {
      if (canvas && video && isCameraActive && video.readyState === 4) {
        const ctx = canvas.getContext('2d');
        if (ctx && aCtx) {
          const w = canvas.width;
          const h = canvas.height;
          const aw = aCanvas.width;
          const ah = aCanvas.height;

          // 1. Draw mirrored webcam image onto display canvas
          ctx.save();
          ctx.clearRect(0, 0, w, h);
          ctx.translate(w, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(video, 0, 0, w, h);
          ctx.restore();

          // 2. Draw downscaled frame to analysis canvas for fast pixel processing
          aCtx.save();
          aCtx.translate(aw, 0);
          aCtx.scale(-1, 1);
          aCtx.drawImage(video, 0, 0, aw, ah);
          aCtx.restore();

          frameCount++;

          // 3. Process image data every 2 frames for super fluid ~30fps recognition
          if (frameCount % 2 === 0) {
            try {
              const imgData = aCtx.getImageData(0, 0, aw, ah);
              const data = imgData.data;

              // Skin segmentation in YCbCr & RGB space
              let sumX = 0;
              let sumY = 0;
              let skinPixelCount = 0;

              let minX = aw;
              let maxX = 0;
              let minY = ah;
              let maxY = 0;

              // Threshold ranges based on lighting sensitivity
              const cbMin = sensitivity === 'dim' ? 70 : 77;
              const cbMax = sensitivity === 'dim' ? 140 : 130;
              const crMin = sensitivity === 'dim' ? 128 : 133;
              const crMax = sensitivity === 'dim' ? 185 : 175;

              // Define central tracking bounding ROI to focus on hand
              const roiLeft = Math.floor(aw * 0.1);
              const roiRight = Math.floor(aw * 0.9);
              const roiTop = Math.floor(ah * 0.05);
              const roiBottom = Math.floor(ah * 0.95);

              const skinMask: boolean[] = new Array(aw * ah).fill(false);

              for (let y = roiTop; y < roiBottom; y += 2) {
                for (let x = roiLeft; x < roiRight; x += 2) {
                  const idx = (y * aw + x) * 4;
                  const r = data[idx];
                  const g = data[idx + 1];
                  const b = data[idx + 2];

                  // YCbCr color conversion
                  const yVal = 0.299 * r + 0.587 * g + 0.114 * b;
                  const cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
                  const cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;

                  // Universal human skin tone threshold
                  const isSkin =
                    yVal > 35 &&
                    cb >= cbMin &&
                    cb <= cbMax &&
                    cr >= crMin &&
                    cr <= crMax &&
                    r > g &&
                    r > b &&
                    (r - g) > 8;

                  if (isSkin) {
                    skinMask[y * aw + x] = true;
                    sumX += x;
                    sumY += y;
                    skinPixelCount++;

                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                  }
                }
              }

              // Check if hand is reliably present in frame (minimum skin mass)
              if (skinPixelCount > 60) {
                setHandDetected(true);

                // Hand centroid / palm center
                const rawCx = sumX / skinPixelCount;
                const rawCy = sumY / skinPixelCount;

                // Scale to full display canvas coordinates
                const scaleX = w / aw;
                const scaleY = h / ah;
                const cx = rawCx * scaleX;
                const cy = rawCy * scaleY;

                // Hand dimensions
                const boxW = Math.max(80, (maxX - minX) * scaleX * 1.1);
                const boxH = Math.max(90, (maxY - minY) * scaleY * 1.1);
                const handBoxX = (minX * scaleX) - (boxW * 0.05);
                const handBoxY = (minY * scaleY) - (boxH * 0.05);

                // Analyze 5 finger sectors radiating upward from palm center
                // Sample 5 distinct radial directional rays:
                // Angles relative to vertical up (-90 degrees):
                // Thumb: -45 deg, Index: -18 deg, Middle: 0 deg, Ring: +18 deg, Pinky: +40 deg
                const checkRayExtension = (angleDeg: number): number => {
                  const rad = ((angleDeg - 90) * Math.PI) / 180;
                  const dx = Math.cos(rad);
                  const dy = Math.sin(rad);

                  // Palm base distance
                  const baseR = 15;
                  const maxR = 48;
                  let skinAlongRay = 0;

                  for (let r = baseR; r <= maxR; r += 2) {
                    const sx = Math.floor(rawCx + dx * r);
                    const sy = Math.floor(rawCy + dy * r);
                    if (sx >= 0 && sx < aw && sy >= 0 && sy < ah) {
                      if (skinMask[sy * aw + sx]) {
                        skinAlongRay++;
                      }
                    }
                  }

                  const totalSteps = (maxR - baseR) / 2;
                  const ratio = skinAlongRay / totalSteps;
                  return ratio > 0.45 ? 1 : ratio > 0.2 ? 0.5 : 0;
                };

                const measuredThumb = checkRayExtension(-42);
                const measuredIndex = checkRayExtension(-16);
                const measuredMiddle = checkRayExtension(0);
                const measuredRing = checkRayExtension(18);
                const measuredPinky = checkRayExtension(42);

                // Temporal exponential smoothing (0.7 old + 0.3 new) to prevent jitter
                const prev = smoothedFingersRef.current;
                const smoothThumb = prev.thumb * 0.65 + measuredThumb * 0.35;
                const smoothIndex = prev.index * 0.65 + measuredIndex * 0.35;
                const smoothMiddle = prev.middle * 0.65 + measuredMiddle * 0.35;
                const smoothRing = prev.ring * 0.65 + measuredRing * 0.35;
                const smoothPinky = prev.pinky * 0.65 + measuredPinky * 0.35;

                smoothedFingersRef.current = {
                  thumb: smoothThumb,
                  index: smoothIndex,
                  middle: smoothMiddle,
                  ring: smoothRing,
                  pinky: smoothPinky
                };

                setLiveFingers({
                  thumb: Math.round(smoothThumb * 10) / 10,
                  index: Math.round(smoothIndex * 10) / 10,
                  middle: Math.round(smoothMiddle * 10) / 10,
                  ring: Math.round(smoothRing * 10) / 10,
                  pinky: Math.round(smoothPinky * 10) / 10
                });

                // Match with dictionary pattern
                if (timestamp - lastMatchTimestampRef.current > 350) {
                  lastMatchTimestampRef.current = timestamp;
                  matchPattern({
                    thumb: smoothThumb > 0.4 ? 1 : smoothThumb > 0.2 ? 0.5 : 0,
                    index: smoothIndex > 0.4 ? 1 : smoothIndex > 0.2 ? 0.5 : 0,
                    middle: smoothMiddle > 0.4 ? 1 : smoothMiddle > 0.2 ? 0.5 : 0,
                    ring: smoothRing > 0.4 ? 1 : smoothRing > 0.2 ? 0.5 : 0,
                    pinky: smoothPinky > 0.4 ? 1 : smoothPinky > 0.2 ? 0.5 : 0
                  });
                }

                // 4. Draw REAL LIVE Tracked Hand Skeleton & Dynamic Bounding Box
                if (showSkeleton) {
                  // Bounding Box with corner reticles
                  ctx.strokeStyle = '#38bdf8';
                  ctx.lineWidth = 2;
                  ctx.strokeRect(handBoxX, handBoxY, boxW, boxH);

                  // Corner brackets
                  const bSize = 14;
                  ctx.strokeStyle = '#818cf8';
                  ctx.lineWidth = 3.5;
                  // Top-left
                  ctx.beginPath(); ctx.moveTo(handBoxX, handBoxY + bSize); ctx.lineTo(handBoxX, handBoxY); ctx.lineTo(handBoxX + bSize, handBoxY); ctx.stroke();
                  // Top-right
                  ctx.beginPath(); ctx.moveTo(handBoxX + boxW - bSize, handBoxY); ctx.lineTo(handBoxX + boxW, handBoxY); ctx.lineTo(handBoxX + boxW, handBoxY + bSize); ctx.stroke();
                  // Bottom-left
                  ctx.beginPath(); ctx.moveTo(handBoxX, handBoxY + boxH - bSize); ctx.lineTo(handBoxX, handBoxY + boxH); ctx.lineTo(handBoxX + bSize, handBoxY + boxH); ctx.stroke();
                  // Bottom-right
                  ctx.beginPath(); ctx.moveTo(handBoxX + boxW - bSize, handBoxY + boxH); ctx.lineTo(handBoxX + boxW, handBoxY + boxH); ctx.lineTo(handBoxX + boxW, handBoxY + boxH - bSize); ctx.stroke();

                  // Palm Center Node
                  ctx.fillStyle = 'rgba(56, 189, 248, 0.3)';
                  ctx.beginPath();
                  ctx.arc(cx, cy, 28, 0, Math.PI * 2);
                  ctx.fill();
                  ctx.strokeStyle = '#38bdf8';
                  ctx.lineWidth = 2;
                  ctx.stroke();

                  // Palm Center Dot
                  ctx.fillStyle = '#38bdf8';
                  ctx.beginPath();
                  ctx.arc(cx, cy, 5, 0, Math.PI * 2);
                  ctx.fill();

                  // Wrist Base
                  const wristY = Math.min(h - 15, cy + 65);
                  ctx.fillStyle = '#818cf8';
                  ctx.beginPath();
                  ctx.arc(cx, wristY, 6, 0, Math.PI * 2);
                  ctx.fill();

                  // Draw 5 Dynamic Tracking Rays & Fingertip Markers connected to User's Hand
                  const fingers = [
                    { name: 'T', angle: -42, ext: smoothThumb, color: '#f59e0b' },
                    { name: 'I', angle: -16, ext: smoothIndex, color: '#38bdf8' },
                    { name: 'M', angle: 0, ext: smoothMiddle, color: '#34d399' },
                    { name: 'R', angle: 18, ext: smoothRing, color: '#818cf8' },
                    { name: 'P', angle: 42, ext: smoothPinky, color: '#ec4899' }
                  ];

                  fingers.forEach(f => {
                    const rad = ((f.angle - 90) * Math.PI) / 180;
                    const reach = 30 + f.ext * 65;
                    const fx = cx + Math.cos(rad) * reach;
                    const fy = cy + Math.sin(rad) * reach;

                    // Joint link
                    ctx.strokeStyle = f.ext > 0.4 ? f.color : 'rgba(100, 116, 139, 0.4)';
                    ctx.lineWidth = f.ext > 0.4 ? 3 : 1.5;
                    ctx.beginPath();
                    ctx.moveTo(cx, cy);
                    ctx.lineTo(fx, fy);
                    ctx.stroke();

                    // Fingertip Node
                    ctx.fillStyle = f.ext > 0.4 ? f.color : '#475569';
                    ctx.beginPath();
                    ctx.arc(fx, fy, f.ext > 0.4 ? 7 : 4, 0, Math.PI * 2);
                    ctx.fill();

                    // Letter Badge
                    ctx.fillStyle = '#ffffff';
                    ctx.font = 'bold 9px monospace';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(f.name, fx, fy);
                  });

                  // Top Tracking Label Tag
                  ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
                  ctx.fillRect(handBoxX, handBoxY - 22, 140, 20);
                  ctx.fillStyle = '#38bdf8';
                  ctx.font = 'bold 11px sans-serif';
                  ctx.textAlign = 'left';
                  ctx.textBaseline = 'middle';
                  ctx.fillText('Tracking Real Hand', handBoxX + 6, handBoxY - 12);
                }
              } else {
                setHandDetected(false);

                // Draw central framing target guide when no hand is in frame
                const cx = w / 2;
                const cy = h / 2;
                ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
                ctx.lineWidth = 2;
                ctx.setLineDash([8, 8]);
                ctx.strokeRect(cx - 100, cy - 120, 200, 240);
                ctx.setLineDash([]);

                ctx.fillStyle = 'rgba(15, 23, 42, 0.8)';
                ctx.fillRect(cx - 100, cy + 70, 200, 32);
                ctx.fillStyle = '#94a3b8';
                ctx.font = '12px sans-serif';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('Place hand inside frame', cx, cy + 86);
              }
            } catch (e) {
              // Frame processing safety
            }
          }
        }
      }
      animId = requestAnimationFrame(processVisionFrame);
    };

    animId = requestAnimationFrame(processVisionFrame);
    return () => cancelAnimationFrame(animId);
  }, [isCameraActive, sensitivity, showSkeleton, matchPattern]);

  // In simulator mode, match pattern when sliders change
  useEffect(() => {
    if (useSimulator) {
      matchPattern({
        thumb: simThumb,
        index: simIndex,
        middle: simMiddle,
        ring: simRing,
        pinky: simPinky
      });
    }
  }, [useSimulator, simThumb, simIndex, simMiddle, simRing, simPinky, matchPattern]);

  // Text append handler
  const handleAppendRecognized = () => {
    if (!currentMatch) return;
    const word = currentMatch.sign.label;
    setAccumulatedText(prev => (prev ? `${prev} ${word}` : word));
  };

  // Text-to-speech speak
  const handleSpeak = () => {
    if (!accumulatedText || !('speechSynthesis' in window)) return;
    setIsSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(accumulatedText);
    utterance.rate = 0.95;
    utterance.onend = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  // Copy text
  const handleCopy = () => {
    if (!accumulatedText) return;
    navigator.clipboard.writeText(accumulatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Quick preset test pose for simulator
  const setPosePreset = (preset: 'A' | 'B' | 'L' | 'V' | '5' | 'Hello') => {
    switch (preset) {
      case 'A':
        setSimThumb(0.9); setSimIndex(0); setSimMiddle(0); setSimRing(0); setSimPinky(0);
        break;
      case 'B':
        setSimThumb(0); setSimIndex(1); setSimMiddle(1); setSimRing(1); setSimPinky(1);
        break;
      case 'L':
        setSimThumb(1); setSimIndex(1); setSimMiddle(0); setSimRing(0); setSimPinky(0);
        break;
      case 'V':
        setSimThumb(0); setSimIndex(1); setSimMiddle(1); setSimRing(0); setSimPinky(0);
        break;
      case '5':
        setSimThumb(1); setSimIndex(1); setSimMiddle(1); setSimRing(1); setSimPinky(1);
        break;
      case 'Hello':
        setSimThumb(0.2); setSimIndex(1); setSimMiddle(1); setSimRing(1); setSimPinky(1);
        break;
    }
  };

  return (
    <div className="bg-slate-900 rounded-2xl border border-slate-800 p-5 shadow-xl space-y-5">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-mono tracking-wider text-emerald-400">
              Live Optical Hand Vision
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">Pixel Skin-Tone & Raycast Tracker</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">Camera Gesture Capture</h2>
        </div>

        {/* Mode Toggles */}
        <div className="flex flex-wrap items-center gap-2">
          {!isCameraActive ? (
            <button
              onClick={startCamera}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition-colors shadow-lg shadow-emerald-600/20"
            >
              <Camera className="w-4 h-4" />
              <span>Enable Camera</span>
            </button>
          ) : (
            <button
              onClick={stopCamera}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs transition-colors"
            >
              <CameraOff className="w-4 h-4" />
              <span>Stop Camera</span>
            </button>
          )}

          {/* Sensitivity Setting */}
          {isCameraActive && (
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-0.5 text-xs">
              <button
                onClick={() => setSensitivity('normal')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  sensitivity === 'normal' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Normal lighting calibration"
              >
                Normal
              </button>
              <button
                onClick={() => setSensitivity('dim')}
                className={`px-2.5 py-1 rounded-lg transition-colors ${
                  sensitivity === 'dim' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
                title="Enhanced sensitivity for low light / dim rooms"
              >
                Low Light
              </button>
            </div>
          )}

          <button
            onClick={() => {
              if (isCameraActive) stopCamera();
              setUseSimulator(!useSimulator);
            }}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium border transition-colors ${
              useSimulator
                ? 'bg-indigo-600 text-white border-indigo-500'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Interactive Tester</span>
          </button>
        </div>
      </div>

      {/* Camera Error Alert if any */}
      {cameraError && (
        <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-800/60 text-amber-200 text-xs flex items-start gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-amber-300">Camera Notice:</p>
            <p className="text-amber-300/80">{cameraError}</p>
          </div>
        </div>
      )}

      {/* Main Viewport Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Camera View / Hand Simulator */}
        <div className="lg:col-span-7 flex flex-col items-center">
          <div className="relative w-full aspect-4/3 max-h-[380px] bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex items-center justify-center shadow-inner">
            {/* Hidden video element for webcam capture */}
            <video ref={videoRef} className="hidden" playsInline muted />

            {isCameraActive ? (
              <canvas
                ref={canvasRef}
                width={640}
                height={480}
                className="w-full h-full object-cover transition-opacity duration-300"
              />
            ) : (
              /* Virtual Simulator / Interactive hand analyzer */
              <div className="w-full h-full p-6 flex flex-col justify-between items-center text-center">
                <div className="space-y-1">
                  <span className="text-xs uppercase font-mono text-indigo-400">Anatomical Hand Simulator</span>
                  <p className="text-xs text-slate-400">
                    Adjust finger joints or select quick poses to test real-time gesture matching.
                  </p>
                </div>

                {/* Finger Sliders */}
                <div className="w-full max-w-sm space-y-2.5 my-2">
                  {[
                    { label: 'Thumb', val: simThumb, setVal: setSimThumb },
                    { label: 'Index', val: simIndex, setVal: setSimIndex },
                    { label: 'Middle', val: simMiddle, setVal: setSimMiddle },
                    { label: 'Ring', val: simRing, setVal: setSimRing },
                    { label: 'Pinky', val: simPinky, setVal: setSimPinky }
                  ].map(f => (
                    <div key={f.label} className="flex items-center justify-between gap-3 text-xs">
                      <span className="w-14 text-left font-medium text-slate-300">{f.label}</span>
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.1"
                        value={f.val}
                        onChange={e => f.setVal(parseFloat(e.target.value))}
                        className="flex-1 accent-indigo-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                      />
                      <span className="w-10 text-right font-mono text-slate-400">
                        {f.val > 0.6 ? 'Open' : f.val > 0.2 ? 'Half' : 'Fold'}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Quick Presets */}
                <div className="flex flex-wrap items-center justify-center gap-1.5 pt-2 border-t border-slate-800/80 w-full">
                  <span className="text-[11px] text-slate-500 mr-1">Presets:</span>
                  {(['A', 'B', 'L', 'V', '5', 'Hello'] as const).map(p => (
                    <button
                      key={p}
                      onClick={() => setPosePreset(p)}
                      className="px-2.5 py-1 text-xs font-semibold rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Overlay Status Pill */}
            <div className="absolute top-3 left-3 bg-slate-900/90 backdrop-blur-md border border-slate-800 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2 shadow-lg z-10">
              <span className={`w-2 h-2 rounded-full ${
                isCameraActive
                  ? handDetected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400 animate-ping'
                  : 'bg-indigo-400'
              }`} />
              <span className="text-slate-300 font-medium">
                {isCameraActive
                  ? handDetected ? 'Hand Locked & Tracked' : 'Searching for Hand...'
                  : 'Interactive Tester Active'}
              </span>
            </div>

            {/* Live Real-Time Finger Extension Meter on Canvas */}
            {isCameraActive && handDetected && (
              <div className="absolute bottom-3 left-3 right-3 bg-slate-950/85 backdrop-blur-md border border-slate-800 px-3 py-2 rounded-xl text-[11px] flex items-center justify-between text-slate-300 z-10">
                <div className="flex items-center gap-1 font-mono text-indigo-400">
                  <Target className="w-3.5 h-3.5" />
                  <span>Optical Raycast:</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span>T: <strong className={liveFingers.thumb > 0.4 ? 'text-emerald-400' : 'text-slate-500'}>{liveFingers.thumb > 0.4 ? '▲' : '▼'}</strong></span>
                  <span>I: <strong className={liveFingers.index > 0.4 ? 'text-emerald-400' : 'text-slate-500'}>{liveFingers.index > 0.4 ? '▲' : '▼'}</strong></span>
                  <span>M: <strong className={liveFingers.middle > 0.4 ? 'text-emerald-400' : 'text-slate-500'}>{liveFingers.middle > 0.4 ? '▲' : '▼'}</strong></span>
                  <span>R: <strong className={liveFingers.ring > 0.4 ? 'text-emerald-400' : 'text-slate-500'}>{liveFingers.ring > 0.4 ? '▲' : '▼'}</strong></span>
                  <span>P: <strong className={liveFingers.pinky > 0.4 ? 'text-emerald-400' : 'text-slate-500'}>{liveFingers.pinky > 0.4 ? '▲' : '▼'}</strong></span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Live Recognized Real Sign Card */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
          <div className="bg-slate-950/80 rounded-2xl border border-slate-800/90 p-4">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800/80">
              <span className="text-xs text-slate-400 uppercase font-mono">Live Recognized Sign</span>
              {currentMatch && (
                <div className="flex items-center gap-1 text-xs text-emerald-400 font-semibold font-mono">
                  <span>{currentMatch.confidence}% confidence</span>
                </div>
              )}
            </div>

            {currentMatch ? (
              <div className="flex flex-col items-center space-y-3">
                <div className="flex items-center gap-4">
                  <RealSignVisual
                    sign={currentMatch.sign}
                    size="sm"
                    showControls={false}
                    showMotionArrows={false}
                  />
                  <div>
                    <h4 className="text-3xl font-extrabold text-white tracking-tight">{currentMatch.sign.label}</h4>
                    <p className="text-xs text-indigo-400 font-semibold capitalize mt-0.5">{currentMatch.sign.category}</p>
                    <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">{currentMatch.sign.handshape}</p>
                  </div>
                </div>

                <button
                  onClick={handleAppendRecognized}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/30"
                >
                  <span>Insert "{currentMatch.sign.label}" into Sentence</span>
                </button>
              </div>
            ) : (
              <div className="py-8 text-center text-slate-500 space-y-2">
                <Target className="w-7 h-7 mx-auto text-slate-600 animate-pulse" />
                <p className="text-xs font-semibold text-slate-400">
                  {isCameraActive ? 'Hold a sign clearly in front of camera' : 'Start camera or use tester to classify gestures'}
                </p>
                <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                  Extend fingers clearly (e.g. peace sign for "V", open palm for "B" or "5", thumbs-up for "A").
                </p>
              </div>
            )}
          </div>

          {/* Practice Match Feedback (if practicing a specific target) */}
          {targetSignForPractice && (
            <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-800/60 text-xs">
              <span className="text-indigo-400 font-semibold">Current Goal: </span>
              <span className="text-white font-bold">{targetSignForPractice.label}</span>
              {currentMatch?.sign.id === targetSignForPractice.id ? (
                <p className="text-emerald-400 font-semibold mt-1">✓ Perfect Match! Handshape verified!</p>
              ) : (
                <p className="text-slate-400 mt-1">Shape your hand to match the target above.</p>
              )}
            </div>
          )}

          {/* Quick Sign Picker fallback for instant selection */}
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800 text-xs space-y-1.5">
            <span className="text-slate-400 font-medium block">Quick Sign Shortcuts:</span>
            <div className="flex flex-wrap gap-1">
              {['Hello', 'Thank You', 'Help', 'Doctor', 'Yes', 'No', 'Water'].map(signName => {
                const s = SIGN_DICTIONARY.find(entry => entry.label.toLowerCase().includes(signName.toLowerCase()));
                if (!s) return null;
                return (
                  <button
                    key={signName}
                    onClick={() => {
                      setCurrentMatch({ sign: s, confidence: 95 });
                      onSignRecognized?.(s);
                    }}
                    className="px-2 py-1 bg-slate-900 hover:bg-indigo-600 text-slate-300 hover:text-white rounded-md text-[11px] font-semibold border border-slate-800 transition-colors"
                  >
                    {signName}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Accumulated Sentence Output Bar */}
      <div className="bg-slate-950 rounded-2xl border border-slate-800 p-4 space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="uppercase font-mono text-[11px] text-indigo-400">Translated Sign Sentence</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setAccumulatedText(prev => (prev ? `${prev} ` : ''))}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition-colors"
            >
              + Space
            </button>
            <button
              onClick={() => setAccumulatedText(prev => prev.slice(0, -1))}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Backspace"
              aria-label="Backspace"
            >
              <Delete className="w-4 h-4" />
            </button>
            <button
              onClick={() => setAccumulatedText('')}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition-colors"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Text Input / Display */}
        <div className="relative">
          <textarea
            value={accumulatedText}
            onChange={e => setAccumulatedText(e.target.value)}
            placeholder="Recognized signs will append here, or type directly..."
            rows={2}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-indigo-500 resize-none font-medium leading-relaxed"
          />
        </div>

        {/* Speech and Copy Actions */}
        <div className="flex items-center justify-between pt-1">
          <div className="text-xs text-slate-500">
            {accumulatedText.split(/\s+/).filter(Boolean).length} words · {accumulatedText.length} characters
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleSpeak}
              disabled={!accumulatedText || isSpeaking}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 disabled:opacity-50 text-slate-200 text-xs font-medium transition-colors"
            >
              <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>{isSpeaking ? 'Speaking...' : 'Speak Aloud'}</span>
            </button>
            <button
              onClick={handleCopy}
              disabled={!accumulatedText}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 disabled:opacity-50 text-slate-200 text-xs font-medium transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Text'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

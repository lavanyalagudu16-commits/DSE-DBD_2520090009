import React from 'react';
import { SignEntry } from '../types/sign';
import { RealSignVisual } from './RealSignVisual';
import { X, Volume2, Sparkles, Check, AlertCircle, Info, Bookmark } from 'lucide-react';

interface DictionaryModalProps {
  sign: SignEntry | null;
  onClose: () => void;
  onAddToPhrase?: (sign: SignEntry) => void;
}

export const DictionaryModal: React.FC<DictionaryModalProps> = ({
  sign,
  onClose,
  onAddToPhrase
}) => {
  if (!sign) return null;

  const handleSpeak = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(`${sign.label}. ${sign.description}`);
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Modal Top Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between sticky top-0 bg-slate-900/95 backdrop-blur-md z-10">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-indigo-400">
                <span className="uppercase tracking-wider">{sign.dialect} Standard</span>
                <span className="text-slate-600">·</span>
                <span className="capitalize text-slate-400">{sign.category}</span>
              </div>
              <h3 className="text-2xl font-black text-white tracking-tight flex items-center gap-2 mt-0.5">
                {sign.label}
                <button
                  onClick={handleSpeak}
                  className="p-1 rounded-md text-slate-400 hover:text-indigo-400 transition-colors"
                  title="Speak sign"
                  aria-label="Speak sign"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 space-y-6">
          {/* Main Visualizer Stage */}
          <div className="flex flex-col items-center justify-center p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80">
            <RealSignVisual
              sign={sign}
              size="lg"
              showControls={true}
              showMotionArrows={true}
              interactive={true}
              autoPlay={true}
            />
          </div>

          {/* Linguistic Parameters Matrix */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono text-indigo-400 uppercase">1. Handshape</span>
              <p className="font-semibold text-white">{sign.handshape}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono text-indigo-400 uppercase">2. Palm Orientation</span>
              <p className="font-semibold text-white">{sign.palmOrientation}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono text-indigo-400 uppercase">3. Signing Location</span>
              <p className="font-semibold text-white">{sign.location}</p>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[11px] font-mono text-indigo-400 uppercase">4. Movement Dynamic</span>
              <p className="font-semibold text-white">{sign.movement}</p>
            </div>
          </div>

          {/* Detailed Instructions & Tips */}
          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1 text-xs leading-relaxed">
              <h4 className="font-semibold text-white flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-indigo-400" />
                <span>Execution Steps</span>
              </h4>
              <p className="text-slate-300">{sign.description}</p>
            </div>

            {sign.tips && (
              <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-800/40 space-y-1 text-xs">
                <h4 className="font-semibold text-indigo-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Pro Articulation Tip</span>
                </h4>
                <p className="text-slate-300">{sign.tips}</p>
              </div>
            )}

            {sign.commonErrors && sign.commonErrors.length > 0 && (
              <div className="p-4 rounded-xl bg-amber-950/20 border border-amber-800/40 space-y-1 text-xs">
                <h4 className="font-semibold text-amber-300 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Common Mistakes to Avoid</span>
                </h4>
                <ul className="list-disc list-inside text-slate-300 space-y-0.5">
                  {sign.commonErrors.map((err, idx) => (
                    <li key={idx}>{err}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="p-5 border-t border-slate-800 flex items-center justify-between sticky bottom-0 bg-slate-900/95 backdrop-blur-md">
          <span className="text-xs text-slate-500 font-medium">
            Two-handed: {sign.twoHanded ? 'Yes' : 'No'}
          </span>

          <div className="flex items-center gap-2">
            {onAddToPhrase && (
              <button
                onClick={() => {
                  onAddToPhrase(sign);
                  onClose();
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition-colors shadow-md shadow-indigo-600/20"
              >
                + Add to Phrase Builder
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

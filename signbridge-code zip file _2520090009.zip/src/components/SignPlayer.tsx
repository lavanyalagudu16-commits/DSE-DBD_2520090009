import React, { useState, useEffect } from 'react';
import { SignEntry } from '../types/sign';
import { RealSignVisual } from './RealSignVisual';
import { Play, Pause, RotateCcw, ChevronLeft, ChevronRight, Volume2, Sparkles, SkipBack, SkipForward, SpellCheck } from 'lucide-react';

interface SignPlayerProps {
  signs: SignEntry[];
  sentenceText?: string;
  onSignComplete?: () => void;
  autoPlay?: boolean;
}

export const SignPlayer: React.FC<SignPlayerProps> = ({
  signs,
  sentenceText,
  onSignComplete,
  autoPlay = false
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlayingSequence, setIsPlayingSequence] = useState(autoPlay);
  const [playbackSpeed, setPlaybackSpeed] = useState<0.5 | 1 | 1.5>(1);

  // Auto-clamp or reset index when signs list changes
  useEffect(() => {
    if (currentIndex >= signs.length) {
      setCurrentIndex(Math.max(0, signs.length - 1));
    }
  }, [signs.length, currentIndex]);

  const currentSign = signs[currentIndex] || signs[0];

  // Sequence playback timer
  useEffect(() => {
    if (!isPlayingSequence || signs.length === 0) return;

    // Fingerspelled letters play slightly faster for natural cadence
    const baseTime = currentSign?.isFingerspelled ? 1100 : 1800;
    const intervalTime = baseTime / playbackSpeed;

    const timer = setTimeout(() => {
      if (currentIndex < signs.length - 1) {
        setCurrentIndex(prev => prev + 1);
      } else {
        setIsPlayingSequence(false);
        onSignComplete?.();
      }
    }, intervalTime);

    return () => clearTimeout(timer);
  }, [isPlayingSequence, currentIndex, signs.length, playbackSpeed, currentSign, onSignComplete]);

  // Audio Speech Synthesis
  const speakCurrent = () => {
    if (!currentSign) return;
    if ('speechSynthesis' in window) {
      const textToSpeak = currentSign.isFingerspelled
        ? `${currentSign.sourceWord || currentSign.label}`
        : currentSign.label;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Jump to next whole word in sequence
  const jumpNextWord = () => {
    if (!currentSign) return;
    const currentWord = currentSign.sourceWord;
    for (let i = currentIndex + 1; i < signs.length; i++) {
      if (signs[i].sourceWord !== currentWord) {
        setCurrentIndex(i);
        return;
      }
    }
    // If no further word, go to end
    setCurrentIndex(signs.length - 1);
  };

  // Jump to previous whole word in sequence
  const jumpPrevWord = () => {
    if (!currentSign) return;
    const currentWord = currentSign.sourceWord;
    // Step backwards to find previous word
    for (let i = currentIndex - 1; i >= 0; i--) {
      if (signs[i].sourceWord !== currentWord) {
        // Find start of that word
        const prevWord = signs[i].sourceWord;
        let startIdx = i;
        while (startIdx > 0 && signs[startIdx - 1].sourceWord === prevWord) {
          startIdx--;
        }
        setCurrentIndex(startIdx);
        return;
      }
    }
    setCurrentIndex(0);
  };

  if (!currentSign || signs.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500 rounded-2xl border border-dashed border-slate-800">
        <p className="text-sm">No signs in sequence to play.</p>
      </div>
    );
  }

  const isFingerspelled = !!currentSign.isFingerspelled;
  const wordDisplay = currentSign.sourceWord || currentSign.label;

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-5 shadow-xl">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800/80 mb-4 gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-mono tracking-wider text-indigo-400">
              Sign {currentIndex + 1} of {signs.length}
            </span>
            <span className="text-slate-600">·</span>
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-md ${
              isFingerspelled
                ? 'bg-amber-950/60 text-amber-300 border border-amber-800/60'
                : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/60'
            }`}>
              {isFingerspelled ? 'Fingerspelling' : 'Whole-Word Sign'}
            </span>
          </div>

          <div className="flex items-center gap-3 mt-1.5">
            <h3 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <span>{isFingerspelled ? `Letter "${currentSign.label}"` : currentSign.label}</span>
              <button
                onClick={speakCurrent}
                className="p-1 rounded-md text-slate-400 hover:text-indigo-400 hover:bg-slate-800 transition-colors"
                title="Speak sign name"
                aria-label="Speak sign name"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </h3>

            {isFingerspelled && (
              <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                Word: <strong className="text-indigo-300">{wordDisplay}</strong>
              </span>
            )}
          </div>

          {/* Letter progress breadcrumbs for fingerspelled words */}
          {isFingerspelled && wordDisplay && (
            <div className="flex flex-wrap items-center gap-1 mt-2">
              {wordDisplay.split('').map((char, cIdx) => {
                const isActive = cIdx === ((currentSign.letterIndex || 1) - 1);
                return (
                  <span
                    key={`${char}-${cIdx}`}
                    className={`px-2 py-0.5 text-xs font-mono font-bold rounded-md transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/50 scale-110'
                        : 'bg-slate-950 text-slate-400 border border-slate-800'
                    }`}
                  >
                    {char}
                  </span>
                );
              })}
            </div>
          )}
        </div>

        {/* Speed Controls */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          {([0.5, 1, 1.5] as const).map(speed => (
            <button
              key={speed}
              onClick={() => setPlaybackSpeed(speed)}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                playbackSpeed === speed
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {speed}x
            </button>
          ))}
        </div>
      </div>

      {/* Main Real Sign Visualizer with unique key to prevent freeze on repeat letters */}
      <div className="flex flex-col items-center justify-center my-2">
        <RealSignVisual
          key={`${currentSign.id}-${currentIndex}`}
          sign={currentSign}
          size="lg"
          showControls={false}
          showMotionArrows={true}
          playbackSpeed={playbackSpeed}
          autoPlay={true}
        />
      </div>

      {/* Linguistic Description Box */}
      <div className="mt-4 bg-slate-950/70 rounded-xl p-3 border border-slate-800/80 text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
          <div>
            <span className="text-slate-500 font-medium">Handshape: </span>
            <span className="text-slate-200">{currentSign.handshape}</span>
          </div>
          <div>
            <span className="text-slate-500 font-medium">Movement: </span>
            <span className="text-slate-200">{currentSign.movement}</span>
          </div>
        </div>
        <p className="mt-2 text-slate-400 leading-relaxed">
          {currentSign.description}
        </p>
      </div>

      {/* Timeline scrubbing & sequence player */}
      <div className="mt-5 space-y-3">
        {/* Progress bar */}
        <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
          <div
            className="bg-indigo-500 h-full transition-all duration-300 rounded-full"
            style={{ width: `${((currentIndex + 1) / signs.length) * 100}%` }}
          />
        </div>

        {/* Sequencer Buttons with Word Jumpers */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              onClick={jumpPrevWord}
              disabled={currentIndex === 0}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-300 transition-colors"
              title="Previous Word"
              aria-label="Previous Word"
            >
              <SkipBack className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentIndex(Math.max(0, currentIndex - 1))}
              disabled={currentIndex === 0}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-white transition-colors"
              title="Previous Sign"
              aria-label="Previous sign"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setIsPlayingSequence(!isPlayingSequence)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs transition-colors shadow-lg shadow-indigo-600/20"
            >
              {isPlayingSequence ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlayingSequence ? 'Pause Sequence' : 'Play Sequence'}</span>
            </button>
            <button
              onClick={() => setCurrentIndex(Math.min(signs.length - 1, currentIndex + 1))}
              disabled={currentIndex === signs.length - 1}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-white transition-colors"
              title="Next Sign"
              aria-label="Next sign"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={jumpNextWord}
              disabled={currentIndex === signs.length - 1}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-300 transition-colors"
              title="Next Word"
              aria-label="Next Word"
            >
              <SkipForward className="w-4 h-4" />
            </button>
            <button
              onClick={() => {
                setCurrentIndex(0);
                setIsPlayingSequence(true);
              }}
              className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Restart sequence"
              aria-label="Restart sequence"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          <div className="text-xs text-slate-400 font-mono">
            {currentIndex + 1} / {signs.length} signs
          </div>
        </div>

        {/* Thumbnail Sequence Strip with Word Groupings */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-2 border-t border-slate-800/60">
          {signs.map((s, idx) => {
            const isSelected = idx === currentIndex;
            const isFs = s.isFingerspelled;

            return (
              <button
                key={`${s.id}-${idx}`}
                onClick={() => {
                  setCurrentIndex(idx);
                  setIsPlayingSequence(false);
                }}
                className={`flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex flex-col items-center min-w-[50px] ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/50 scale-105'
                    : 'bg-slate-800/70 text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <span className="font-bold">{s.label}</span>
                {isFs && s.sourceWord && (
                  <span className={`text-[9px] truncate max-w-[45px] ${isSelected ? 'text-indigo-200' : 'text-slate-400'}`}>
                    {s.sourceWord}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

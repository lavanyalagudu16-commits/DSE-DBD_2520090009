/**
 * SignBridge - Domain Data Types
 */

export type SignCategory =
  | 'alphabet'
  | 'number'
  | 'greeting'
  | 'emergency'
  | 'healthcare'
  | 'daily'
  | 'questions'
  | 'social';

export type SignDialect = 'ASL' | 'ISL' | 'BSL' | 'Universal';

export type MotionType =
  | 'static'
  | 'sweep-forward'
  | 'tap'
  | 'circle'
  | 'wave'
  | 'bounce'
  | 'cross'
  | 'open-close'
  | 'pulse'
  | 'chin-forward'
  | 'chest-rub'
  | 'point'
  | 'nod';

export interface GesturePattern {
  thumb: number; // 0 (curled) to 1 (extended)
  index: number;
  middle: number;
  ring: number;
  pinky: number;
  palmFacing?: 'outward' | 'inward' | 'side' | 'upward' | 'downward';
}

export interface SignEntry {
  id: string;
  label: string;
  category: SignCategory;
  handshape: string;
  palmOrientation: string;
  location: string;
  movement: string;
  description: string;
  tips: string;
  dialect: SignDialect;
  pattern: GesturePattern;
  twoHanded: boolean;
  motionType: MotionType;
  secondaryLabel?: string;
  commonErrors?: string[];
  usageExample?: string;
  sourceWord?: string;
  isFingerspelled?: boolean;
  letterIndex?: number;
  wordTotalLetters?: number;
}

export interface RecognizedGesture {
  label: string;
  confidence: number;
  signId?: string;
  patternMatched: GesturePattern;
  timestamp: number;
}

export interface PracticeExercise {
  id: string;
  signId: string;
  targetLabel: string;
  prompt: string;
  hint: string;
}
